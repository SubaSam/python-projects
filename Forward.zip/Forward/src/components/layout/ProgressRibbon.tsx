import { Check, AlertCircle } from "lucide-react";
import { useLocation, useNavigate } from "react-router-dom";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";

const stages = [
  { label: "Upload", path: "/upload" },
  // { label: "Qualifier", path: "/qualifier" },
  { label: "Metadata", path: "/metadata" },
  { label: "Validation", path: "/validation" },
  { label: "Code Gen", path: "/codegen" },
  { label: "Code Validation", path: "/code-validation" },
  { label: "Complete", path: "/completion" },
];

export function ProgressRibbon() {
  const location = useLocation();
  const navigate = useNavigate();
  const currentIndex = stages.findIndex((s) => s.path === location.pathname);

  return (
    <div className="flex items-center gap-1 px-4 py-3 bg-surface border-b border-border/50 overflow-x-auto">
      {stages.map((stage, i) => {
        const isActive = location.pathname === stage.path;
        const isPast = currentIndex > i;
        const isFuture = currentIndex < i;

        return (
          <div key={stage.label} className="flex items-center">
            <button
              onClick={() => navigate(stage.path)}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-semibold transition-all cursor-pointer
                ${isActive ? "bg-primary/20 text-primary ring-1 ring-primary/30" : ""}
                ${isPast ? "bg-success/15 text-success" : ""}
                ${isFuture ? "text-muted-foreground/50 hover:text-muted-foreground" : ""}
              `}
            >
              {isPast ? (
                <Check className="w-3 h-3" />
              ) : (
                <span className="w-2 h-2 rounded-full bg-current opacity-40" />
              )}
              <span>{stage.label}</span>
            </button>
            {i < stages.length - 1 && (
              <div className={`w-8 h-px mx-1 ${isPast ? "bg-success/40" : "bg-border"}`} />
            )}
          </div>
        );
      })}
    </div>
  );
}
