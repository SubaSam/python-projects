import {
  Upload,
  Database,
  ShieldCheck,
  Code2,
  CheckCircle2,
  Zap,
  BarChart3,
  FileCheck,
} from "lucide-react";
import { NavLink } from "@/components/NavLink";
import { useLocation } from "react-router-dom";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  useSidebar,
} from "@/components/ui/sidebar";

const navItems = [
  // { title: "Spec Upload", url: "/upload", icon: Upload },
  // { title: "Qualifier Analysis", url: "/qualifier", icon: BarChart3 },
  // { title: "Metadata", url: "/metadata", icon: Database },
  // { title: "Validation", url: "/validation", icon: ShieldCheck },
  // { title: "Code Generation", url: "/codegen", icon: Code2 },
  // { title: "Code Validation", url: "/code-validation", icon: FileCheck },
  // { title: "Completion", url: "/completion", icon: CheckCircle2 },
  
  { title: "Specification Intake", url: "/upload", icon: Upload },
  // { title: "Performance Analytics", url: "/qualifier", icon: BarChart3 },
  { title: "Architecture Blueprint", url: "/metadata", icon: Database },
  { title: "Coverage Verification", url: "/validation", icon: ShieldCheck },
  { title: "Source Code Synthesis", url: "/codegen", icon: Code2 },
  { title: "Build Quality Audit", url: "/code-validation", icon: FileCheck },
  { title: "Delivery Readiness", url: "/completion", icon: CheckCircle2 },
];

const handleReverseEngineeringClick = () => {
  window.location.href = "http://10.73.82.86:5173/codegenie"; // CodeSpectre landing page
};

export function AppSidebar() {
  const { state } = useSidebar();
  const collapsed = state === "collapsed";
  const location = useLocation();

  return (
    <Sidebar collapsible="icon" className="border-r border-sidebar-border">
      <SidebarHeader className="p-4">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
            <Zap className="w-4 h-4 text-primary-foreground" />
          </div>
          {!collapsed && (
            <div>
              <h1 className="text-sm font-bold text-foreground">Forward Engineering</h1>
              <p className="text-[11px] text-muted-foreground cursor-pointer" onClick={handleReverseEngineeringClick}>CODEGENIE</p>
            </div>
          )}
        </div>
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel className="text-[10px] tracking-widest text-muted-foreground/60">
            Pipeline
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {navItems.map((item) => {
                const active = location.pathname === item.url;
                return (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton asChild>
                      <NavLink
                        to={item.url}
                        end
                        className={`transition-all duration-200 ${active ? "bg-primary/15 text-primary" : "hover:bg-muted/50"}`}
                        activeClassName="bg-primary/15 text-primary font-semibold"
                      >
                        <item.icon className="mr-2 h-4 w-4" />
                        {!collapsed && <span>{item.title}</span>}
                      </NavLink>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                );
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>
  );
}
