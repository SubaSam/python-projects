import { ReactNode } from "react";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";

interface MetricCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon?: ReactNode;
  trend?: string;
  variant?: "default" | "primary" | "success" | "warning" | "destructive";
  className?: string;
}

const variantClasses = {
  default: "border-border/50",
  primary: "border-primary/30 glow-primary",
  success: "border-success/30",
  warning: "border-warning/30",
  destructive: "border-destructive/30",
};

const valueClasses = {
  default: "text-foreground",
  primary: "text-primary",
  success: "text-success",
  warning: "text-warning",
  destructive: "text-destructive",
};

export function MetricCard({
  title,
  value,
  subtitle,
  icon,
  trend,
  variant = "default",
  className = "",
}: MetricCardProps) {
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <div
          className={`glass-card p-5 flex flex-col gap-3 animate-fade-in hover:scale-[1.02] transition-transform duration-200 ${variantClasses[variant]} ${className}`}
        >
          <div className="flex items-center justify-between">
            <span className="metric-label">{title}</span>
            {icon && <span className="text-muted-foreground">{icon}</span>}
          </div>
          <div className={`metric-number ${valueClasses[variant]}`}>{value}</div>
          {subtitle && (
            <p className="text-xs text-muted-foreground">{subtitle}</p>
          )}
        </div>
      </TooltipTrigger>
      {trend && (
        <TooltipContent className="bg-card border-border">
          <p className="text-xs">{trend}</p>
        </TooltipContent>
      )}
    </Tooltip>
  );
}
