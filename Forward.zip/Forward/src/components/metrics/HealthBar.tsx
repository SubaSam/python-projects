interface HealthBarProps {
  label: string;
  value: number;
  max?: number;
}

export function HealthBar({ label, value, max = 100 }: HealthBarProps) {
  const pct = Math.min((value / max) * 100, 100);
  const color =
    pct >= 80 ? "bg-success" : pct >= 50 ? "bg-warning" : "bg-destructive";

  return (
    <div className="flex-1 min-w-[200px]">
      <div className="flex justify-between mb-1">
        <span className="text-xs font-medium text-muted-foreground">{label}</span>
        <span className="text-xs font-bold text-foreground">{value}%</span>
      </div>
      <div className="h-2 rounded-full bg-muted overflow-hidden">
        <div
          className={`h-full rounded-full ${color} transition-all duration-1000 ease-out`}
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
}
