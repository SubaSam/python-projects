import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes, Navigate } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AppLayout } from "@/components/layout/AppLayout";
import SpecUpload from "./pages/SpecUpload";
import QualifierAnalysis from "./pages/QualifierAnalysis";
import Metadata from "./pages/Metadata";
import Validation from "./pages/Validation";
import CodeGeneration from "./pages/CodeGeneration";
import CodeValidation from "./pages/CodeValidation";
import Completion from "./pages/Completion";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AppLayout>
          <Routes>
            <Route path="/" element={<Navigate to="/upload" replace />} />
            <Route path="/upload" element={<SpecUpload />} />
            {/* <Route path="/qualifier" element={<QualifierAnalysis />} /> */}
            <Route path="/metadata" element={<Metadata />} />
            <Route path="/validation" element={<Validation />} />
            <Route path="/codegen" element={<CodeGeneration />} />
            <Route path="/code-validation" element={<CodeValidation />} />
            <Route path="/completion" element={<Completion />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </AppLayout>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
