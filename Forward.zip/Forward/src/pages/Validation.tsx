import { ArrowLeft, ArrowRight, Edit, Link2 } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { InfoTooltip } from "@/components/metrics/InfoTooltip";
import { DonutChart } from "@/components/metrics/DonutChart";
import { useEffect, useState } from "react";
import { fetchMetadataValidationFiles } from "@/api/api";

export default function Validation() {
  const navigate = useNavigate();
  const [category, setCategory] = useState<string | null>(null);
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

// useEffect(() => {
//   const loadData = async () => {
//     try {
//       const saved = localStorage.getItem("spec_upload_state");
//       const parsed = saved ? JSON.parse(saved) : null;

//       const category = parsed?.category;
//       if (!category) {
//         setLoading(false);
//         return;
//       }

//       const res = await fetchMetadataValidationFiles(category);
//       console.log("API RESPONSE:", res);

//       const validationData =
//         res?.files?.metadata_validation_output?.response?.[0]?.data || null;

//       setData(validationData);
//     } catch (error) {
//       console.error(error);
//     } finally {
//       setLoading(false);
//     }
//   };

//   loadData();
// }, []);
useEffect(() => {
  const loadData = async () => {
    try {
      const saved = localStorage.getItem("spec_upload_state");
      const parsed = saved ? JSON.parse(saved) : null;

      const categoryFromStorage = parsed?.category;
      if (!categoryFromStorage) {
        setLoading(false);
        return;
      }

      setCategory(categoryFromStorage);

      const res = await fetchMetadataValidationFiles(categoryFromStorage);

      const validationData =
        res?.files?.metadata_validation_output?.response?.[0]?.data || null;

      setData(validationData);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  loadData();
}, []);

  if (loading) {
    return <div className="text-center py-10 text-muted-foreground">Loading validation data...</div>;
  }

  if (!data) {
    return <div className="text-center py-10 text-destructive">Failed to load data</div>;
  }

  const overall = data?.overall_summary;
  const categories = data?.category_breakdown;
  const description = data?.meta?.description;

  const coveredPercent = overall?.["overall_coverage_%"] || 0;
  const missingPercent = (100 - coveredPercent).toFixed(2);
const isSas = category === "sas";

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      <div className="flex items-center gap-3">
        <button
          onClick={() => navigate("/metadata")}
          className="p-2 rounded-lg hover:bg-muted/50 text-muted-foreground hover:text-foreground transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        <div>
          <h1 className="text-2xl font-bold text-foreground">Validation</h1>
          {/* <p className="text-sm text-muted-foreground">
            {description || "Specification coverage analysis and gap identification"}
          </p> */}
        </div>
      </div>

      {/* Specification Coverage */}
      <div className="glass-card p-8 flex flex-col items-center gap-4 border-primary/20">
        <div className="flex items-center gap-2">
          <span className="metric-label">Specification Coverage</span>
          <InfoTooltip text={description} />
        </div>

        <div className="relative">
          <DonutChart
            percentage={coveredPercent}
            size={160}
            strokeWidth={14}
            color="hsl(var(--primary))"
          />
        </div>

        <div className="flex gap-6 text-xs text-muted-foreground">
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-success" />
            Covered: {coveredPercent}%
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-destructive" />
            Missing: {missingPercent}%
          </span>
        </div>

        <div className="flex gap-3 mt-2">
          <button
            onClick={() => navigate("/metadata")}
            className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold text-primary hover:bg-primary/10 transition-colors border border-primary/20"
          >
            <Edit className="w-3.5 h-3.5" /> Edit Metadata
          </button>
          {/* <button
            onClick={() => navigate("/metadata")}
            className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold text-muted-foreground hover:bg-muted/50 transition-colors border border-border"
          >
            <Link2 className="w-3.5 h-3.5" /> Go to Metadata
          </button> */}
        </div>
      </div>

      {/* Category Breakdown Table */}
      <div className="glass-card overflow-hidden">
        <div className="p-4 border-b border-border/50 flex items-center gap-2">
          <span className="text-xs font-semibold tracking-widest text-muted-foreground/90 uppercase">
            Category Breakdown
          </span>
          <InfoTooltip text="Coverage details for each category based on metadata validation." />
        </div>

      <div className="overflow-x-auto">
        
  <table className="w-full text-sm">
    <thead>
      <tr className="text-xs text-muted-foreground/100 uppercase tracking-wider border-b border-border/30">
        {/* Wider columns */}
        <th className="w-[15%] text-left p-3 font-medium">
          Name
        </th>

        {/* Compact number columns */}
        <th className="w-[5%] text-left p-3 font-medium">
          Total
        </th>
        <th className="w-[5%] text-left p-3 font-medium">
          Covered
        </th>
        <th className="w-[5%] text-left p-3 font-medium">
          Missed
        </th>
        <th className="w-[8%] text-left p-3 font-medium">
          Coverage %
        </th>

        {/* Wider last column */}
        <th className="w-[30%] text-left p-3 font-medium">
          Missed IDs
        </th>
      </tr>
    </thead>

    {/* <tbody>
      {Object.entries(categories || {}).map(
        ([name, item]: any) => (
          <tr
            key={name}
            className="border-b border-border/20 hover:bg-muted/20 transition-colors"
          >
            <td className="p-3 font-semibold text-primary break-words">
              {name}
            </td>

            <td className="p-3">
              {item.total}
            </td>

            <td className="p-3 text-success">
              {item.covered}
            </td>

            <td className="p-3 text-destructive">
              {item.missed}
            </td>

            <td className="p-3">
              {item.coverage_percent}%
            </td>

            <td className="p-3  text-xs break-words">
              {item.missed_ids?.length
                ? item.missed_ids.join(", ")
                : "—"}
            </td>
          </tr>
        )
      )}
    </tbody> */}
    <tbody>
  {Object.entries(categories || {}).map(
    ([name, item]: any) => {
      const total = isSas
        ? item.spec_count
        : item.total;

      const covered = isSas
        ? item.metadata_count
        : item.covered;

      const missed = isSas
        ? Math.abs(item.delta ?? 0)
        : item.missed;

      return (
        <tr
          key={name}
          className="border-b border-border/20 hover:bg-muted/20 transition-colors"
        >
          <td className="p-3 font-semibold text-primary break-words">
            {name}
          </td>

          <td className="p-3">
            {total}
          </td>

          <td className="p-3 text-success">
            {covered}
          </td>

          <td className="p-3 text-destructive">
            {missed}
          </td>

          <td className="p-3">
            {item.coverage_percent}%
          </td>

          <td className="p-3 text-xs break-words">
            {item.missed_ids?.length
              ? item.missed_ids.join(", ")
              : "—"}
          </td>
        </tr>
      );
    }
  )}
</tbody>
  </table>
</div>
      </div>

      <div className="flex justify-between">
        <button
          onClick={() => navigate("/metadata")}
          className="px-6 py-2.5 rounded-lg border border-border text-muted-foreground font-semibold text-sm hover:bg-muted/50 transition-colors flex items-center gap-2"
        >
          <ArrowLeft className="w-4 h-4" /> Back
        </button>
        <button
          onClick={() => navigate("/codegen")}
          className="px-6 py-2.5 rounded-lg bg-primary text-primary-foreground font-semibold text-sm hover:bg-primary/90 transition-colors flex items-center gap-2"
        >
          Proceed <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}