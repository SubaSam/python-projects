import { ArrowLeft, ArrowRight, Info, FileText, CheckSquare, Circle, AlertTriangle } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { InfoTooltip } from "@/components/metrics/InfoTooltip";
import { DonutChart } from "@/components/metrics/DonutChart";

const appSummary = [
  { dimension: "MS Suitability", result: "YES", color: "text-success", icon: "✅" },
  { dimension: "Architecture", result: "MICROSERVICE", color: "text-primary", icon: "🔵" },
  { dimension: "Transformation Effort", result: "HIGH", color: "text-destructive", icon: "🔴" },
  { dimension: "Files Analysed", result: "5 (5 .md, 0 .docx)", color: "text-foreground", icon: "" },
  { dimension: "Files Converted (.docx→.md)", result: "0", color: "text-foreground", icon: "" },
];

const applicationSummary = {
  summary: "This application is a well-structured, modular COBOL system for Long-Term Care PPS pricing, making it a strong candidate for modernization.",
  keyStrength: "High modularity with a clear separation of concerns: data preparation (LTOPN212), routing/pre-processing (LTDRV212), and versioned calculation (LTCALxxx).",
  keyRisk: "Tight data coupling through large, monolithic data structures (e.g., PPS-DATA-ALL) passed between all modules, preventing clean interface separation.",
};

const microserviceBoundaries = [
  {
    id: 1,
    service: "LtcPpsPricerService",
    responsibility: "Owns the end-to-end business logic for calculating Long-Term Care Hospital PPS payments based on bill, provider, and wage index data.",
    apiContract: "Input: A structured request (e.g., JSON) with bill details. Output: A structured response with the final payment and breakdown.",
  },
];

const fileAnalysis = [
  { file: "LTCAL032.md", format: "md", suitability: "YES", architecture: "MICROSERVICE", concern: "Hard-coded national constants should be externalized into a configuration service." },
  { file: "LTCAL042.md (×2)", format: "md", suitability: "YES", architecture: "MICROSERVICE", concern: "Dependency on in-memory lookup table will require a new data sourcing strategy." },
  { file: "LTDRV212.md (×3)", format: "md", suitability: "YES", architecture: "MICROSERVICE", concern: "The program acts as a driver that calls a separate LTCALxxx module, indicating tight coupling." },
  { file: "LTMGR212.md", format: "md", suitability: "YES", architecture: "HYBRID", concern: "Primary business value resides in the called module (LTOPN212), not this driver program." },
  { file: "LTOPN212.md", format: "md", suitability: "YES", architecture: "MICROSERVICE", concern: "Tight coupling with downstream program LTDRV212 implies co-modernization." },
];

const requiredChanges = [
  { id: 1, change: "Externalize reference data like the DRG table and wage index tables into a database or configuration service.", reason: "To decouple business rules and rates from the application code.", effort: "MEDIUM" },
  { id: 2, change: "Refactor the monolithic PPS-DATA-ALL structure. Define minimal, explicit interfaces for each internal CALL.", reason: "To break tight data coupling between modules.", effort: "HIGH" },
  { id: 3, change: "Eliminate the pps_rtc flag for flow control. Sub-programs should return a distinct status/result object.", reason: "To remove tight behavioral coupling and make logic flow explicit.", effort: "MEDIUM" },
];

const effortBreakdown = [
  { area: "Data Layer Decoupling", effort: "MEDIUM" },
  { area: "API Contract Design", effort: "LOW" },
  { area: "Internal Interface Refactoring", effort: "HIGH" },
];

const effortColor = (e: string) =>
  e === "HIGH" ? "text-destructive" : e === "MEDIUM" ? "text-warning" : "text-success";

const effortDot = (e: string) =>
  e === "HIGH" ? "bg-destructive" : e === "MEDIUM" ? "bg-warning" : "bg-success";

export default function QualifierAnalysis() {
  const navigate = useNavigate();

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      <div className="flex items-center gap-3">
        <button onClick={() => navigate("/upload")} className="p-2 rounded-lg hover:bg-muted/50 text-muted-foreground hover:text-foreground transition-colors">
          <ArrowLeft className="w-4 h-4" />
        </button>
        <div>
          <h1 className="text-2xl font-bold text-foreground">COBOL Application — Microservice Quality & Transformation Report</h1>
          <p className="text-xs text-muted-foreground mt-1">Generated: 2026-04-15 11:11:30 · Files Analysed: 5 · LLM: Google Gemini (gemini-2.5-pro) via Vertex AI</p>
        </div>
      </div>

      {/* Application-Level Summary */}
      <div className="glass-card p-6 space-y-4">
        <div className="flex items-center gap-2">
          <span className="text-base font-bold text-foreground">📊 Application-Level Summary</span>
          <InfoTooltip text="High-level assessment of the application's suitability for microservice transformation." />
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-xs text-muted-foreground/60 uppercase tracking-wider border-b border-border/30">
                <th className="text-left p-3 font-medium">Dimension</th>
                <th className="text-left p-3 font-medium">Result</th>
              </tr>
            </thead>
            <tbody>
              {appSummary.map((row) => (
                <tr key={row.dimension} className="border-b border-border/20">
                  <td className="p-3 font-semibold text-foreground">{row.dimension}</td>
                  <td className={`p-3 font-medium ${row.color}`}>
                    {row.icon && <span className="mr-2">{row.icon}</span>}
                    {row.result}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Application Summary */}
      <div className="glass-card p-6 space-y-4">
        <div className="flex items-center gap-2">
          <span className="text-base font-bold text-foreground">📌 Application Summary</span>
          <InfoTooltip text="AI-generated summary of the application's key characteristics, strengths, and risks." />
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-xs text-muted-foreground/60 uppercase tracking-wider border-b border-border/30">
                <th className="text-left p-3 font-medium w-32">Field</th>
                <th className="text-left p-3 font-medium">Value</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-border/20">
                <td className="p-3 font-semibold text-foreground align-top">Summary</td>
                <td className="p-3 text-muted-foreground">{applicationSummary.summary}</td>
              </tr>
              <tr className="border-b border-border/20">
                <td className="p-3 font-semibold text-foreground align-top">Key Strength</td>
                <td className="p-3 text-muted-foreground">{applicationSummary.keyStrength}</td>
              </tr>
              <tr className="border-b border-border/20">
                <td className="p-3 font-semibold text-foreground align-top">Key Risk</td>
                <td className="p-3 text-muted-foreground">{applicationSummary.keyRisk}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Proposed Microservice Boundaries */}
      <div className="glass-card p-6 space-y-4">
        <div className="flex items-center gap-2">
          <span className="text-base font-bold text-foreground">🧩 Proposed Microservice Boundaries</span>
          <InfoTooltip text="Recommended microservice decomposition based on functional analysis." />
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-xs text-muted-foreground/60 uppercase tracking-wider border-b border-border/30">
                <th className="text-left p-3 font-medium w-8">#</th>
                <th className="text-left p-3 font-medium">Service</th>
                <th className="text-left p-3 font-medium">Responsibility</th>
                <th className="text-left p-3 font-medium">API Contract</th>
              </tr>
            </thead>
            <tbody>
              {microserviceBoundaries.map((row) => (
                <tr key={row.id} className="border-b border-border/20">
                  <td className="p-3 text-muted-foreground">{row.id}</td>
                  <td className="p-3 font-bold text-foreground">{row.service}</td>
                  <td className="p-3 text-muted-foreground">{row.responsibility}</td>
                  <td className="p-3 text-muted-foreground text-xs">{row.apiContract}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Per-File Analysis */}
      <div className="glass-card p-6 space-y-4">
        <div className="flex items-center gap-2">
          <span className="text-base font-bold text-foreground">📁 Per-File Analysis</span>
          <InfoTooltip text="Individual assessment of each analyzed file showing suitability, architecture recommendation, and key concerns." />
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-xs text-muted-foreground/60 uppercase tracking-wider border-b border-border/30">
                <th className="text-left p-3 font-medium">File</th>
                <th className="text-left p-3 font-medium">Format</th>
                <th className="text-left p-3 font-medium">Suitability</th>
                <th className="text-left p-3 font-medium">Architecture</th>
                <th className="text-left p-3 font-medium">Key Concern</th>
              </tr>
            </thead>
            <tbody>
              {fileAnalysis.map((row, i) => (
                <tr key={i} className="border-b border-border/20">
                  <td className="p-3 font-mono text-xs text-foreground">{row.file}</td>
                  <td className="p-3 text-muted-foreground">{row.format}</td>
                  <td className="p-3 text-success font-medium">✅ {row.suitability}</td>
                  <td className="p-3">
                    <span className={`font-medium ${row.architecture === "HYBRID" ? "text-accent" : "text-primary"}`}>
                      {row.architecture === "HYBRID" ? "🟣" : "🔵"} {row.architecture}
                    </span>
                  </td>
                  <td className="p-3 text-xs text-muted-foreground">{row.concern}</td>
                </tr>
              ))}
              <tr className="border-t border-border/40 bg-muted/20">
                <td className="p-3 font-bold text-foreground">Totals</td>
                <td className="p-3 text-muted-foreground">—</td>
                <td className="p-3 text-sm">✅ 5 / 🟡 0 / ❌ 0</td>
                <td className="p-3 text-muted-foreground">—</td>
                <td className="p-3 text-muted-foreground">—</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Required Changes */}
      <div className="glass-card p-6 space-y-4">
        <div className="flex items-center gap-2">
          <span className="text-base font-bold text-foreground">🔧 Required Changes</span>
          <InfoTooltip text="Mandatory architectural changes required before microservice transformation can proceed." />
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-xs text-muted-foreground/60 uppercase tracking-wider border-b border-border/30">
                <th className="text-left p-3 font-medium w-8">#</th>
                <th className="text-left p-3 font-medium">Change</th>
                <th className="text-left p-3 font-medium">Reason</th>
                <th className="text-right p-3 font-medium">Effort</th>
              </tr>
            </thead>
            <tbody>
              {requiredChanges.map((row) => (
                <tr key={row.id} className="border-b border-border/20">
                  <td className="p-3 text-muted-foreground">{row.id}</td>
                  <td className="p-3 text-foreground">{row.change}</td>
                  <td className="p-3 text-muted-foreground">{row.reason}</td>
                  <td className="p-3 text-right">
                    <span className={`inline-flex items-center gap-1.5 font-semibold ${effortColor(row.effort)}`}>
                      <span className={`w-2 h-2 rounded-full ${effortDot(row.effort)}`} />
                      {row.effort}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Effort Breakdown */}
      <div className="glass-card p-6 space-y-4">
        <div className="flex items-center gap-2">
          <span className="text-base font-bold text-foreground">⚙️ Effort Breakdown — Overall: </span>
          <span className="inline-flex items-center gap-1.5 font-bold text-destructive">
            <span className="w-3 h-3 rounded-full bg-destructive" /> HIGH
          </span>
          <InfoTooltip text="Aggregated effort estimate across all transformation areas." />
        </div>
        <div className="max-w-sm">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-xs text-muted-foreground/60 uppercase tracking-wider border-b border-border/30">
                <th className="text-left p-3 font-medium">Area</th>
                <th className="text-left p-3 font-medium">Effort</th>
              </tr>
            </thead>
            <tbody>
              {effortBreakdown.map((row) => (
                <tr key={row.area} className="border-b border-border/20">
                  <td className="p-3 text-muted-foreground">{row.area}</td>
                  <td className="p-3">
                    <span className={`inline-flex items-center gap-1.5 font-semibold ${effortColor(row.effort)}`}>
                      <span className={`w-2 h-2 rounded-full ${effortDot(row.effort)}`} />
                      {row.effort}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Transformation Strategy */}
      <div className="glass-card p-6 space-y-4">
        <span className="text-base font-bold text-foreground">🚀 Transformation Strategy</span>
        <div className="bg-muted/30 rounded-lg p-4 border-l-4 border-primary">
          <p className="text-sm text-muted-foreground">
            Strangler Fig. The entire application suite can be wrapped by a new facade that exposes a modern, clean API. Initially, this facade will translate API calls to the existing COBOL program chain and map the results back. This allows for the gradual, piece-by-piece reimplementation of the COBOL logic behind the stable facade, minimizing risk and disruption to consumers.
          </p>
        </div>
      </div>

      {/* Recommended Next Steps */}
      <div className="glass-card p-6 space-y-4">
        <div className="flex items-center gap-2">
          <span className="text-base font-bold text-foreground">📋 Recommended Next Steps</span>
          <InfoTooltip text="Prioritized action items to begin the modernization process." />
        </div>
        <div className="space-y-3">
          {[
            "Build a comprehensive regression test suite by capturing a large set of inputs and corresponding payment outputs from the current system.",
            "Perform a detailed data-flow analysis of the PPS-DATA-ALL copybook to map every field's usage across all programs.",
            "Develop a prototype 'Strangler' facade that exposes the target JSON API and translates calls to the top-level LTOPN212 COBOL program.",
          ].map((step, i) => (
            <div key={i} className="flex items-start gap-3 p-3 rounded-lg hover:bg-muted/20 transition-colors">
              <span className="text-xs font-bold text-primary mt-0.5">{i + 1}</span>
              <p className="text-sm text-muted-foreground">{step}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="flex justify-between">
        <button onClick={() => navigate("/upload")} className="px-6 py-2.5 rounded-lg border border-border text-muted-foreground font-semibold text-sm hover:bg-muted/50 transition-colors flex items-center gap-2">
          <ArrowLeft className="w-4 h-4" /> Back
        </button>
        <button onClick={() => navigate("/metadata")} className="px-6 py-2.5 rounded-lg bg-primary text-primary-foreground font-semibold text-sm hover:bg-primary/90 transition-colors flex items-center gap-2">
          Proceed<ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
