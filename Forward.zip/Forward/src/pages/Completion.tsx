// ==========================
// 2. UPDATE Completion.tsx
// Full updated component
// ==========================

import {
  Download,
  CheckCircle2,
  ArrowLeft,
} from "lucide-react";

import { useNavigate } from "react-router-dom";
import { HealthBar } from "@/components/metrics/HealthBar";
import { InfoTooltip } from "@/components/metrics/InfoTooltip";
import { toast } from "sonner";

import { downloadGeneratedZip,downloadGeneratedZipsas } from "@/api/api";

export default function Completion() {
  const navigate = useNavigate();

 const handleDownload = async () => {
  try {
    toast.loading("Preparing download...");

    const saved = localStorage.getItem("spec_upload_state");
    const parsed = saved ? JSON.parse(saved) : null;
    const category = parsed?.category ?? "java"; // default java

    // ✅ Pick endpoint based on technology
    const blob =
      category === "sas"
        ? await downloadGeneratedZipsas() // → /download-zip-1
        : await downloadGeneratedZip();   // → /download-zip

    const url = window.URL.createObjectURL(blob);
    const link = document.createElement("a");

    link.href = url;
    link.download =
      category === "sas"
        ? "generated-pyspark-code.zip"
        : "generated-java-code.zip";

    document.body.appendChild(link);
    link.click();
    link.remove();

    window.URL.revokeObjectURL(url);

    toast.dismiss();
    toast.success("Download started!");
  } catch (error) {
    toast.dismiss();
    toast.error("Failed to download zip file");
  }
};

  return (
    <div className="space-y-8 max-w-4xl mx-auto">
      <div className="flex items-center gap-3">
        <button
          onClick={() =>
            navigate(
              "/code-validation"
            )
          }
          className="p-2 rounded-lg hover:bg-muted/50 text-muted-foreground hover:text-foreground transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>

        <div className="flex-1 text-center">
          <CheckCircle2 className="w-16 h-16 text-success mx-auto" />

          <h1 className="text-3xl font-bold text-foreground">
            Generation Complete
          </h1>

          <p className="text-sm text-muted-foreground">
            Confidence summary
            for your pipeline
            run
          </p>
        </div>

        <div className="w-10" />
      </div>

      <div className="grid grid-cols-1 gap-4">
        <div className="glass-card p-6 flex flex-col items-center gap-2 border-success/30">
          <div className="flex items-center gap-2">
            <span className="metric-label">
              Overall Success
            </span>

            <InfoTooltip text="Aggregate success rate across all stages." />
          </div>

          <span className="text-5xl font-black text-success">
            81%
          </span>
        </div>

        {/* <div className="glass-card p-6 flex flex-col items-center gap-2 border-primary/30">
          <div className="flex items-center gap-2">
            <span className="metric-label">
              Code Coverage
            </span>

            <InfoTooltip text="Percentage converted into code." />
          </div>

          <span className="text-5xl font-black text-primary">
            89%
          </span>
        </div> */}
      </div>

      <div className="glass-card p-6 space-y-4">
        <div className="flex items-center gap-2">
          <h2 className="text-xs font-semibold tracking-widest text-muted-foreground/60 uppercase">
            Detailed
            Breakdown
          </h2>

          <InfoTooltip text="Pipeline phase indicators." />
        </div>

        <div className="grid grid-cols-2 gap-6">
          <HealthBar
            label="Design Metadata Coverage"
            value={85}
          />

          <HealthBar
            label="Code Coverage"
            value={80}
          />

          {/* <HealthBar
            label="Code Completeness"
            value={84}
          />

          <HealthBar
            label="Test Readiness"
            value={79}
          /> */}
        </div>
      </div>

      <div className="flex justify-center">
        <button
          onClick={
            handleDownload
          }
          className="px-6 py-3 rounded-lg bg-primary text-primary-foreground font-semibold text-sm hover:bg-primary/90 transition-colors flex items-center gap-2"
        >
          <Download className="w-4 h-4" />
          Download Full
          Codebase
        </button>
      </div>
      <div >
        <button
          onClick={() => navigate("/code-validation")}
          className="px-6 py-2.5 rounded-lg border text-sm flex items-center gap-2"
        >
          <ArrowLeft className="w-4 h-4" />
          Back 
        </button>
      </div>  
    </div>
  );
}