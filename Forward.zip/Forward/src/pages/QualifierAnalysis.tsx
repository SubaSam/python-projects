import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, ArrowRight } from "lucide-react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";

// import { ScoreRing } from "@/components/report/ScoreRing";

export default function QualityPage() {
  const [content, setContent] = useState("");
  const [score, setScore] = useState<number | null>(null);

  const navigate = useNavigate();

useEffect(() => {
  const stored = localStorage.getItem("quality_data");

  if (stored) {
    const parsed = JSON.parse(stored);

    const md = parsed?.content || "";

    setContent(md);

    const match = md.match(
      /Application Readiness Score:\s*`(\d+)%`/
    );

    if (match) {
      setScore(Number(match[1]));
    }
  }
}, []);

  return (
    <div className="max-w-6xl mx-auto space-y-6">

      {/* HEADER */}
      <div className="flex items-center gap-3">
        <button
          onClick={() => navigate("/upload")}
          className="p-2 rounded-lg hover:bg-muted"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>

        <div>
          <h1 className="text-2xl font-bold">Performance Analysis</h1>
          <p className="text-sm text-muted-foreground">
            Microservice readiness & transformation insights
          </p>
        </div>
      </div>

      {/* SCORE (structured UI) */}
      {/* {score !== null && (
        <div className="flex justify-center">
          <ScoreRing value={score} size={160} stroke={14} />
        </div>
      )} */}

      {/* MARKDOWN CONTENT */}
      {!content ? (
        <div className="text-muted-foreground">No report available</div>
      ) : (
        <div className="bg-card rounded-xl shadow p-6 prose prose-sm max-w-none
                        prose-headings:text-foreground
                        prose-p:text-muted-foreground
                        prose-strong:text-foreground
                        prose-table:border
                        prose-th:bg-muted
                        prose-th:p-2
                        prose-td:p-2
                        prose-td:border">

        <ReactMarkdown
  remarkPlugins={[remarkGfm]}
  components={{
    h2: ({ node, ...props }) => (
      <h2 className="mt-10 mb-4 text-2xl font-bold border-b pb-2 text-foreground" {...props} />
    ),

    h3: ({ node, ...props }) => (
      <h3 className="mt-6 mb-3 text-lg font-semibold text-primary" {...props} />
    ),

    p: ({ node, ...props }) => (
      <p className="text-sm leading-relaxed text-muted-foreground mb-3" {...props} />
    ),

    ul: ({ node, ...props }) => (
      <ul className="space-y-2 pl-5 list-disc" {...props} />
    ),

    li: ({ node, ...props }) => (
      <li className="text-sm text-muted-foreground" {...props} />
    ),

    blockquote: ({ node, ...props }) => (
      <div className="border-l-4 border-primary bg-muted/40 px-4 py-3 rounded-md text-sm text-foreground my-4">
        {props.children}
      </div>
    ),

    table: ({ node, ...props }) => (
      <div className="overflow-x-auto my-4 rounded-xl border">
        <table className="w-full text-sm" {...props} />
      </div>
    ),

    thead: ({ node, ...props }) => (
      <thead className="bg-muted/60 text-xs uppercase text-muted-foreground" {...props} />
    ),

    th: ({ node, ...props }) => (
      <th className="px-4 py-2 text-left font-semibold" {...props} />
    ),

    td: ({ node, ...props }) => (
      <td className="px-4 py-2 border-t text-muted-foreground" {...props} />
    ),

    hr: () => (
      <div className="my-8 border-t border-dashed" />
    ),

    strong: ({ node, ...props }) => (
      <strong className="text-foreground font-semibold" {...props} />
    ),
  }}
>
  {content}
</ReactMarkdown>
        </div>
      )}

      {/* FOOTER NAV */}
      <div className="flex justify-between">
        <button
          onClick={() => navigate("/upload")}
          className="px-6 py-2.5 rounded-lg border text-muted-foreground flex items-center gap-2"
        >
          <ArrowLeft className="w-4 h-4" /> Back
        </button>

        <button
          onClick={() => navigate("/metadata")}
          className="px-6 py-2.5 rounded-lg bg-primary text-white flex items-center gap-2"
        >
          Proceed<ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}