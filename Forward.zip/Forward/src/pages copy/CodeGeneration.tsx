import { useEffect, useState } from "react";
import {
  ArrowLeft,
  ArrowRight,
  Server,
  Layers,
  FileCode,
  AlertTriangle,
  GitBranch,
  Database,
  ShieldCheck,
  Eye,
  Boxes,
} from "lucide-react";
import { useNavigate } from "react-router-dom";

import { fetchCodegenMetrics } from "@/api/api";
import { InfoTooltip } from "@/components/metrics/InfoTooltip";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";

/* TYPES */
/* -------------------------------------------------- */

interface GeneratedItem {
  name: string;
  type: string;
  status: "generated";
}

interface MetricCategory {
  label: string;
  count: number;
  icon: any;
  info: string;
  items: GeneratedItem[];
}

interface ApiResponse {
  microservices: {
    count: number;
    names: string[];
  };
  components: any;
}

/* -------------------------------------------------- */
/* COLORS */
/* -------------------------------------------------- */


const getIconForCategory = (category?: string) => {
  switch (category?.toLowerCase()) {
    case "input":
      return Database;
    case "transformation":
      return Layers;
    case "output":
      return Server;
    default:
      return Boxes;
  }
};

const statusColor: Record<string, string> = {
  generated: "bg-primary/15 text-primary border-primary/30",
};

const iconMap: Record<string, any> = {
  CONTROLLER: Server,
  SERVICE: Layers,
  DTOs: FileCode,
  EXCEPTION: AlertTriangle,
  ENDPOINTS: GitBranch,
  ENTITY: Database,
  REPOSITORY: ShieldCheck,
};

/* -------------------------------------------------- */
/* COMPONENT */
/* -------------------------------------------------- */

export default function CodeGeneration() {
  const navigate = useNavigate();

  const [metricCards, setMetricCards] = useState<MetricCategory[]>([]);
  const [activeSheet, setActiveSheet] = useState<MetricCategory | null>(null);
  const [loading, setLoading] = useState(true);

  /* -------------------------------------------------- */
  /* FETCH API */
  /* -------------------------------------------------- */

useEffect(() => {
  loadMetrics();
}, []);

const ALLOWED_SAS_METRIC_LABELS = [
  "Number of Sources",
  "Number of Source Location",
  "Number of Input Schema",

  "Number of Business Rules",
  "Number of Joins",
  "Number of Aggregation Logic",
  "Number of Column Derivation",

  "Number of Sinks",
  "Number of Sink Locations",
  "Number of Output Schemas",
  "Number of Partitioning Scheme",
];

const loadMetrics = async () => {
  try {
    setLoading(true);

    const saved = localStorage.getItem("spec_upload_state");
    const parsed = saved ? JSON.parse(saved) : null;
    const category = parsed?.category;

    if (!category) {
      setLoading(false);
      return;
    }

    const res = await fetchCodegenMetrics(category);

    console.log("CODEGEN:", res);

    /* -------------------------------------- */
    /* JAVA RESPONSE */
    /* -------------------------------------- */
    if (category.toLowerCase() === "java") {
      const data: ApiResponse = res.response;

      const cards: MetricCategory[] = [];

      cards.push({
        label: "Microservices",
        count: data.microservices.count,
        icon: Boxes,
        info: "Total generated microservices.",
        items: data.microservices.names.map((name) => ({
          name,
          type: "Service",
          status: "generated",
        })),
      });

      Object.entries(data.components).forEach(
        ([key, value]: [string, any]) => {
          if (key === "overall_summary") return;

          const items: GeneratedItem[] = [];

          Object.entries(value.by_domain || {}).forEach(
            ([domain, names]: [string, any]) => {
              names.forEach((itemName: string) => {
                items.push({
                  name: itemName,
                  type: domain,
                  status: "generated",
                });
              });
            }
          );

          cards.push({
            label: key,
            count: value.generated ?? value.total_count ?? 0,
            icon: iconMap[key] || Boxes,
            info: `${key} generated from all services.`,
            items,
          });
        }
      );

      setMetricCards(cards);
    }

else if (category.toLowerCase() === "sas") {
  console.log("RAW SAS RESPONSE:", res);

  // ✅ Updated path after removing double wrapping
  // const metrics =
  // res?.files?.["Code_metrics_output"]?.response?.[0]?.data?.metrics ?? [];
 const rawMetrics =
  res?.files?.["Code_metrics_output"]?.response?.[0]?.data?.metrics ?? [];

const metrics = rawMetrics.filter((item: any) =>
  ALLOWED_SAS_METRIC_LABELS.includes(item.metric)
);

  console.log("Extracted metrics array:", metrics);
  console.log("Number of metrics found:", metrics.length);

  if (!metrics.length) {
    console.error("❌ No metrics found. Full response:", res);
    setMetricCards([]);
    return;
  }

  const cards: MetricCategory[] = metrics.map((item: any, index: number) => ({
    label: item.metric || `Metric ${index + 1}`,
    count: item.value ?? 0,
    icon: getIconForCategory(item.category),
    info: item.description || "No description available",
    items: [
      {
        name: item.metric || "Unknown",
        type: item.category || "General",
        status: "generated" as const,
      },
    ],
  }));

  setMetricCards(cards);
}

  } catch (error) {
    console.error(error);
  } finally {
    setLoading(false);
  }
};

  return (
    
    <div className="space-y-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex items-center gap-3">
        <button
          onClick={() => navigate("/validation")}
          className="p-2 rounded-lg hover:bg-muted/50"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>

        <div>
          <h1 className="text-2xl font-bold">Source Code Synthesis</h1>
          <p className="text-sm text-muted-foreground">
            Generated Java microservices output summary
          </p>
        </div>
      </div>

      {/* Cards */}
      {loading ? (
        <div className="text-center py-10 text-muted-foreground">
          Loading metrics...
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          {metricCards.map((m) => (
            <div
              key={m.label}
              onClick={() => setActiveSheet(m)}
              className="glass-card p-5 flex flex-col items-center gap-3 hover:scale-[1.02] transition-transform cursor-pointer group"
            >
              <div className="flex items-center gap-2">
                <span className="metric-label">{m.label}</span>
                <InfoTooltip text={m.info} />
              </div>

              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center">
                <m.icon className="w-6 h-6 text-primary" />
              </div>

              <span className="text-3xl font-black">{m.count}</span>

              <button className="flex items-center gap-1 text-[11px] font-medium text-primary">
                <Eye className="w-3 h-3" />
                View Details
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Sheet */}
      {/* <Sheet
        open={!!activeSheet}
        onOpenChange={(open) => !open && setActiveSheet(null)}
      >
        <SheetContent className="w-full sm:max-w-xl">
          {activeSheet && (
            <>
              <SheetHeader className="pb-4 border-b">
                <SheetTitle className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center">
                    <activeSheet.icon className="w-5 h-5 text-primary" />
                  </div>

                  {activeSheet.label}

                  <Badge className="ml-auto">
                    {activeSheet.count} items
                  </Badge>
                </SheetTitle>

                <SheetDescription>{activeSheet.info}</SheetDescription>
              </SheetHeader>

              <ScrollArea className="h-[calc(100vh-180px)] mt-4 -mx-2 px-2">
                <div className="space-y-2">
                  {activeSheet.items.map((item, i) => (
                    <div
                      key={i}
                      className="flex items-center justify-between p-3 rounded-lg border bg-muted/30"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <span className="text-xs font-mono text-muted-foreground w-6">
                          {i + 1}.
                        </span>

                        <span className="text-sm font-medium truncate">
                          {item.name}
                        </span>
                      </div>

                      <div className="flex items-center gap-2 shrink-0 ml-3">
                        <span className="text-[10px] font-mono text-muted-foreground">
                          {item.type}
                        </span>

                        <Badge
                          variant="outline"
                          className={`text-[10px] px-1.5 py-0 ${statusColor[item.status]}`}
                        >
                          {item.status}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </>
          )}
        </SheetContent>
      </Sheet> */}
    <Dialog
  open={!!activeSheet}
  onOpenChange={(open) => !open && setActiveSheet(null)}
>
  <DialogContent className="max-w-3xl max-h-[90vh] overflow-hidden rounded-2xl">
    {activeSheet && (
      <>
        {/* HEADER */}
        <DialogHeader className="border-b pb-4 pr-5">
          <DialogTitle className="flex items-center gap-3 text-xl">
            <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
              <activeSheet.icon className="w-5 h-5 text-primary" />
            </div>

            {activeSheet.label}

            
            {/* Count Badge */}
            <Badge className="ml-auto">
              {activeSheet.count} items
            </Badge>
          </DialogTitle>

          <DialogDescription>
            {activeSheet.info}
          </DialogDescription>
        </DialogHeader>

        {/* BODY */}
        <ScrollArea className="h-[70vh] pr-3 mt-4">
          <div className="space-y-5">
            {Object.entries(
              activeSheet.items.reduce((acc: any, item) => {
                if (!acc[item.type]) acc[item.type] = [];
                acc[item.type].push(item);
                return acc;
              }, {})
            ).map(([serviceName, rows]: any, index) => (
              <div
                key={index}
                className="rounded-xl border bg-muted/20 p-4"
              >
                {/* SERVICE HEADER */}
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-bold text-primary text-sm">
                    {serviceName}
                  </h3>

                  {/* Generated Label Near Row Header */}
                  <Badge
                    variant="outline"
                    className="text-[10px] px-2 py-0 bg-primary/10 text-primary border-primary/30"
                  >
                    Generated
                  </Badge>
                </div>

                {/* ROW CATEGORY */}
                {/* <div className="text-xs uppercase text-muted-foreground mb-2 tracking-wide">
                  {activeSheet.label}
                </div> */}

                {/* VALUES */}
                <div className="grid sm:grid-cols-2 gap-2">
                  {rows.map((row: any, i: number) => (
                    <div
                      key={i}
                      className="rounded-lg bg-background border px-3 py-2 text-sm font-medium"
                    >
                      {row.name}
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </>
    )}
  </DialogContent>
</Dialog>

      {/* Footer */}
      <div className="flex justify-between">
        <button
          onClick={() => navigate("/validation")}
          className="px-6 py-2.5 rounded-lg border flex items-center gap-2"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Validation
        </button>

        <button
          onClick={() => navigate("/code-validation")}
          className="px-6 py-2.5 rounded-lg bg-primary text-primary-foreground flex items-center gap-2"
        >
          Proceed to Code Validation
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}