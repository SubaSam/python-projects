import {
  ArrowLeft,
  ArrowRight,
  FileText,
  Code2,
  Maximize2,
  Edit,
  Save,
  X,
  Boxes,
  ShieldCheck,
  AlertTriangle,
  Database,
  Layers,
  Minimize2,
  Server,
  FileCode,
  Briefcase,
} from "lucide-react";

import remarkBreaks from "remark-breaks";
import { useNavigate } from "react-router-dom";
import { InfoTooltip } from "@/components/metrics/InfoTooltip";
import { useEffect, useState } from "react";
import {
  ResizablePanelGroup,
  ResizablePanel,
  ResizableHandle,
} from "@/components/ui/resizable";

import {
  fetchMetadataMetrics,
  fetchMetadataFiles,
} from "@/api/api";

import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";

const iconMap: any = {
  business_rules: Briefcase,
  technical_validations: ShieldCheck,
  db_tables: Database,
  error_codes_technical: AlertTriangle,
  error_codes_business: AlertTriangle,
  error_codes_external: AlertTriangle,
  exception_cases: FileCode,
  external_systems: Server,
  batch_jobs: Layers,
};

const metricDescriptions: any = {
  // JAVA
  business_rules: "Business rules identified from specifications.",
  technical_validations: "Technical validations and constraints.",
  db_tables: "Database tables used.",
  error_codes_technical: "Technical error codes.",
  error_codes_business: "Business error codes.",
  error_codes_external: "External system errors.",
  exception_cases: "Exception handling scenarios.",
  external_systems: "Integrated systems.",
  batch_jobs: "Batch processes.",

  // PYSPARK
  pyspark_jobs: "Total PySpark jobs.",
  data_quality_checks: "Data validation checks.",
  transformation_steps: "Transformations applied.",
  sources: "Input data sources.",
  sinks: "Output targets.",
  runtime_params: "Runtime parameters.",
  exception_mappings: "Exception mappings.",
};

export default function Metadata() {
  const navigate = useNavigate();

  const [maximizedPane, setMaximizedPane] =
    useState<"spec" | "metadata" | null>(null);

  const [data, setData] = useState<any>(null);
  const [preview, setPreview] = useState<any>(null);

  // ✅ FIXED STATES
  const [isServicesOpen, setIsServicesOpen] =
    useState(false);

  const [expandedService, setExpandedService] =
    useState<string | null>(null);

  const [loading, setLoading] = useState(true);

  const [editingFile, setEditingFile] =
    useState<string | null>(null);

  const [editedContent, setEditedContent] =
    useState("");
  const [category, setCategory] = useState("sas");
  
 const javaSummaryKeys = [
  "business_rules",
  "technical_validations",
  "db_tables",
  "error_codes_technical",
  "error_codes_business",
  "error_codes_external",
  "exception_cases",
  "external_systems",
  "batch_jobs",
];

const pysparkSummaryKeys = [
  "pyspark_jobs",
  "business_rules",
  "data_quality_checks",
  "transformation_steps",
  "sources",
  "sinks",
  "runtime_params",
  "exception_mappings",

];

const summaryKeys =
  category === "java"
    ? javaSummaryKeys
    : pysparkSummaryKeys;
  useEffect(() => {
    loadData();
  }, []);

// ... existing imports and component ...

const loadData = async () => {
  try {
    setLoading(true);

    // ✅ ALWAYS use selectedCategory locally
    const saved = localStorage.getItem("spec_upload_state");
    const parsed = saved ? JSON.parse(saved) : null;
    const selectedCategory = parsed?.category || "sas";

    setCategory(selectedCategory);

    console.log("Loading data for category:", selectedCategory);

    /* ================= FILES ================= */
    const metaRes = await fetchMetadataFiles(selectedCategory); // ✅ FIXED
    const filesData = metaRes?.files || metaRes || {};

    const metadataFiles = [
      ...(filesData.design_metadata_output_1?.response || []),
      ...(filesData.design_metadata_output_2?.response || []),
      ...(filesData.design_metadata_output_3?.response || []),
    ].filter(Boolean);

    const specFiles = [
      ...(filesData.spec_docs_output_1?.response || []),
      ...(filesData.spec_docs_output_2?.response || []),
      ...(filesData.spec_docs_output_3?.response || []),
    ].filter(Boolean);

    setPreview({
      spec_files: specFiles,
      metadata_files: metadataFiles,
    });

    /* ================= SUMMARY ================= */
    let summaryData: any = {};

    const isJava = selectedCategory
      ?.toLowerCase()
      ?.includes("java");

    // if (isJava) {
    //   // ✅ JAVA → parse markdown JSON
    //   if (metadataFiles.length > 0) {
    //     try {
    //       const content = metadataFiles[0]?.content || "";

    //       const match = content.match(
    //         /```json\s*([\s\S]*?)\s*```/
    //       );

    //       if (match?.[1]) {
    //         const parsedJson = JSON.parse(match[1]);

    //         summaryData =
    //           parsedJson?.data?.summary ||
    //           parsedJson?.summary ||
    //           {};
    //       }
    //     } catch (err) {
    //       console.warn("Java parse failed:", err);
    //     }
    //   }
    // } 
    if (isJava) {
  try {
    const metricsRes = await fetchMetadataMetrics(selectedCategory);

    console.log("JAVA METRICS RESPONSE:", metricsRes);

    summaryData =
      metricsRes?.files?.spec_metrics_output?.response?.[0]?.data?.summary ||
      {};

  } catch (err) {
    console.error("Java metrics fetch failed:", err);
  }
}
    else {
      // ✅ PYSPARK → DIRECT API (NO MARKDOWN PARSING)
      try {
        const metricsRes = await fetchMetadataMetrics(selectedCategory);

        console.log("METRICS RESPONSE:", metricsRes);

        // summaryData = metricsRes?.data?.summary || {};
        summaryData =
  metricsRes?.files?.metadata_metrics_output?.response?.[0]?.data?.summary ||
  {};


      } catch (err) {
        console.error("Metrics fetch failed:", err);
      }
    }

    console.log("FINAL SUMMARY:", summaryData);

    // ✅ IMPORTANT: ensure it's not undefined
    setData({
      summary: summaryData || {},
    });

  } catch (error) {
    console.error("Failed to load metadata:", error);
  } finally {
    setLoading(false);
  }
};

  const handleEdit = (file: any) => {
    setEditingFile(file.filename);
    setEditedContent(file.content);
  };

  const handleCancel = () => {
    setEditingFile(null);
    setEditedContent("");
  };

  const handleSubmit = () => {
    const updatedFiles =
      preview.metadata_files.map((file: any) =>
        file.filename === editingFile
          ? {
              ...file,
              content: editedContent,
            }
          : file
      );

    setPreview({
      ...preview,
      metadata_files: updatedFiles,
    });

    setEditingFile(null);
    setEditedContent("");
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex items-center gap-3">
        <button
          onClick={() => navigate("/qualifier")}
          className="p-2 rounded-lg hover:bg-muted/50"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>

        <div>
          <h1 className="text-2xl font-bold">
            Architecture Blueprint
          </h1>

          <p className="text-sm text-muted-foreground">
            Metrics summary from uploaded specification
          </p>
        </div>
      </div>

      {/* Loading */}
      {loading && (
        <div className="glass-card p-8 text-center text-sm text-muted-foreground">
          Loading metadata...
        </div>
      )}

      {/* Metric Cards */}
     {/* Metric Cards */}
{/* Metric Cards */}
{/* {!loading && data?.summary && (
  <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
    {summaryKeys.map((key) => {
      const Icon = iconMap[key] || Boxes;
      const count = data.summary[key] ?? 0;

      return (
        <div
          key={key}
          className="glass-card p-5 flex flex-col items-center gap-3"
        >
          <div className="flex items-center gap-2 text-center">
            <span className="metric-label capitalize text-xs">
              {key.replaceAll("_", " ")}
            </span>
            <InfoTooltip text={metricDescriptions[key]} />
          </div>

          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center">
            <Icon className="w-6 h-6 text-primary" />
          </div>

          <span className="text-3xl font-black text-foreground">
            {count}
          </span>
        </div>
      );
    })}
  </div>
)} */}
{!loading && data?.summary && (
  <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
    {summaryKeys.map((key) => {
      const Icon = iconMap[key] || Boxes;
      const value = data.summary[key] ?? 0;

      return (
        <div
          key={key}
          className="glass-card p-5 flex flex-col items-center gap-3"
        >
          <div className="flex items-center gap-2 text-center">
            <span className="metric-label capitalize text-xs">
              {key.replaceAll("_", " ")}
            </span>
            <InfoTooltip
              text={metricDescriptions[key] || "Metric summary"}
            />
          </div>

          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center">
            <Icon className="w-6 h-6 text-primary" />
          </div>

          <span className="text-3xl font-black text-foreground">
            {value}
          </span>
        </div>
      );
    })}
  </div>
)}
      {/* Domain Services */}
      {!loading && data?.per_service && (
        <div className="glass-card p-6 space-y-4">
          {/* Main Accordion */}
          <button
            onClick={() =>
              setIsServicesOpen(!isServicesOpen)
            }
            className="w-full flex items-center justify-between rounded-xl border px-4 py-3 hover:bg-muted/20 transition"
          >
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold tracking-widest text-muted-foreground uppercase">
                Domain Services
              </span>

              <InfoTooltip text="Service wise metrics breakdown." />
            </div>

            <span className="text-xs text-primary">
              {isServicesOpen
                ? "Hide Services"
                : "View Services"}
            </span>
          </button>

          {/* Services Body */}
          {isServicesOpen && (
            <div className="space-y-3 max-h-[420px] overflow-y-auto pr-2">
              {data.per_service.map((service: any) => {
                const isOpen =
                  expandedService ===
                  service.service;

                return (
                  <div
                    key={service.service}
                    className="border rounded-xl overflow-hidden"
                  >
                    {/* Service Header */}
                    <button
                      onClick={() =>
                        setExpandedService(
                          isOpen
                            ? null
                            : service.service
                        )
                      }
                      className="w-full flex justify-between p-4 hover:bg-muted/20 text-left"
                    >
                      <div>
                        <span className="font-semibold text-sm">
                          {service.service}
                        </span>

                        <p className="text-xs text-muted-foreground mt-1">
                          Generated metadata components
                          from specification analysis
                        </p>
                      </div>

                      <span className="text-xs text-primary">
                        {isOpen
                          ? "Hide Details"
                          : "View Details"}
                      </span>
                    </button>

                    {/* Service Details */}
                    {isOpen && (
                      <div className="p-4 max-h-[250px] overflow-y-auto">
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
                          {summaryKeys.map((item) => (
                            <div
                              key={item}
                              className="text-center p-3 rounded-lg bg-muted/30"
                            >
                              <div className="text-xl font-bold">
                                {service[item] ?? 0}
                              </div>

                              <div className="text-[10px] uppercase text-muted-foreground">
                                {item.replaceAll(
                                  "_",
                                  " "
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

     {/* Spec ↔ Metadata Comparison */}
      {!loading &&
        preview?.metadata_files &&
        preview?.spec_files && (
          <div className="glass-card p-6 space-y-4">
            <div className="flex items-center justify-between flex-wrap gap-3">
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold tracking-widest text-muted-foreground/60 uppercase">
                  Spec ↔ Metadata Comparison
                </span>

                <InfoTooltip text="Side-by-side view of original specification and generated metadata." />
              </div>

              <button
                onClick={() =>
                  setMaximizedPane(null)
                }
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors border ${
                  maximizedPane === null
                    ? "bg-primary/15 text-primary border-primary/30"
                    : "text-muted-foreground border-border hover:bg-muted/50"
                }`}
              >
                <Minimize2 className="w-3.5 h-3.5" />
                Split View
              </button>
            </div>

            <div className="h-[520px] rounded-lg border border-border/30 overflow-hidden bg-muted/10 flex flex-col">
              <ResizablePanelGroup
                direction="horizontal"
                className="h-full"
              >
                {/* Spec Panel */}
                {maximizedPane !== "metadata" && (
                   <ResizablePanel
                    defaultSize={50}
                    minSize={20}
                    className="flex flex-col"
                  >
                    {preview.spec_files.map(
                      (file: any) => {
                        const isEditing =
                          editingFile ===
                          file.filename;

                        return (
                          <div
                            key={file.filename}
                            className="flex flex-col h-full"
                          >
                            <div className="flex justify-between items-center p-2 border-b border-border/30 bg-surface/60">
                              <div className="flex items-center gap-2">
                                <div className="w-7 h-7 rounded-md bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center">
                                  <Code2 className="w-3.5 h-3.5 text-primary" />
                                </div>

                                <div className="flex flex-col">
                                  <span className="text-xs font-bold">
                                    Generated Spec
                                  </span>

                                  <span className="text-[10px] text-muted-foreground">
                                    {
                                      file.filename
                                    }
                                  </span>
                                </div>
                              </div>

                              <div className="flex gap-2">
                          

                               <button
                                  onClick={() =>
                                    setMaximizedPane(
                                      maximizedPane === "spec"
                                        ? null
                                        : "spec"
                                    )
                                  }
                                  className="p-1.5 rounded-md hover:bg-muted/50"
                                >
                                  {maximizedPane === "spec" ? (
                                    <Minimize2 className="w-3.5 h-3.5" />
                                  ) : (
                                    <Maximize2 className="w-3.5 h-3.5" />
                                  )}
                                </button>
                              </div>
                            </div>

                            <div className="flex-1 overflow-auto p-4 font-mono text-xs leading-relaxed text-muted-foreground bg-muted/20">
                              {isEditing ? (
                                <textarea
                                  value={
                                    editedContent
                                  }
                                  onChange={(
                                    e
                                  ) =>
                                    setEditedContent(
                                      e.target
                                        .value
                                    )
                                  }
                                  className="w-full h-full rounded-lg border p-4 bg-muted/20 text-sm font-mono"
                                />
                              ) : (
                                <div className="flex-1 overflow-auto bg-muted/20">
                                  <div className="p-6">
                                    <div className="whitespace-pre-wrap text-sm leading-7 text-muted-foreground font-medium">
                                      {file.content}
                                    </div>
                                  </div>
                                </div>
                              )}
                            </div>
                          </div>
                        );
                      }
                    )}
                  </ResizablePanel>
                  
                )}

                {maximizedPane === null && (
                  <ResizableHandle
                    withHandle
                    className="bg-border/40"
                  />
                )}

                {/* Metadata Panel */}
                {maximizedPane !== "spec" && (
                  <ResizablePanel
                    defaultSize={50}
                    minSize={20}
                    className="flex flex-col"
                  >
                    {preview.metadata_files.map(
                      (file: any) => {
                        const isEditing =
                          editingFile ===
                          file.filename;

                        return (
                          <div
                            key={file.filename}
                            className="flex flex-col h-full"
                          >
                            <div className="flex justify-between items-center px-4 py-2.5 border-b border-border/30 bg-surface/60">
                              <div className="flex items-center gap-2">
                                <div className="w-7 h-7 rounded-md bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center">
                                  <Code2 className="w-3.5 h-3.5 text-primary" />
                                </div>

                                <div className="flex flex-col">
                                  <span className="text-xs font-bold">
                                    Generated Metadata
                                  </span>

                                  <span className="text-[10px] text-muted-foreground">
                                    {
                                      file.filename
                                    }
                                  </span>
                                </div>
                              </div>

                              <div className="flex gap-2">
                                {!isEditing ? (
                                  <button
                                    onClick={() =>
                                      handleEdit(
                                        file
                                      )
                                    }
                                    className="px-3 py-1.5 rounded-lg border text-xs flex items-center gap-2"
                                  >
                                    <Edit className="w-4 h-4" />
                                    Edit
                                  </button>
                                ) : (
                                  <>
                                    <button
                                      onClick={
                                        handleSubmit
                                      }
                                      className="px-3 py-1.5 rounded-lg bg-primary text-white text-xs flex items-center gap-2"
                                    >
                                      <Save className="w-4 h-4" />
                                      Submit
                                    </button>

                                    <button
                                      onClick={
                                        handleCancel
                                      }
                                      className="px-3 py-1.5 rounded-lg border text-xs flex items-center gap-2"
                                    >
                                      <X className="w-4 h-4" />
                                      Cancel
                                    </button>
                                  </>
                                )}

                                <button
                                  onClick={() =>
                                    setMaximizedPane(
                                      maximizedPane ===
                                        "metadata"
                                        ? null
                                        : "metadata"
                                    )
                                  }
                                  className="p-1.5 rounded-md hover:bg-muted/50"
                                >
                                  {maximizedPane ===
                                  "metadata" ? (
                                    <Minimize2 className="w-3.5 h-3.5" />
                                  ) : (
                                    <Maximize2 className="w-3.5 h-3.5" />
                                  )}
                                </button>
                              </div>
                            </div>

                            <div className="flex-1 overflow-auto p-4 font-mono text-xs leading-relaxed text-muted-foreground bg-muted/20">
                              {isEditing ? (
                                <textarea
                                  value={
                                    editedContent
                                  }
                                  onChange={(
                                    e
                                  ) =>
                                    setEditedContent(
                                      e.target
                                        .value
                                    )
                                  }
                                  className="w-full h-full rounded-lg border p-4 bg-muted/20 text-sm font-mono"
                                />
                              ) : (
                                <ReactMarkdown
                                  remarkPlugins={[
                                    remarkGfm,
                                  ]}
                                >
                                  {
                                    file.content
                                  }
                                </ReactMarkdown>
                              )}
                            </div>
                          </div>
                        );
                      }
                    )}
                  </ResizablePanel>
                )}
              </ResizablePanelGroup>
            </div>
          </div>
        )}

      {/* Footer */}
      <div className="flex justify-between">
        <button
          onClick={() =>
            navigate("/qualifier")
          }
          className="px-6 py-2.5 rounded-lg border text-sm flex items-center gap-2"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Qualifier Analysis
        </button>

        <button
          onClick={() =>
            navigate("/validation")
          }
          className="px-6 py-2.5 rounded-lg bg-primary text-white text-sm flex items-center gap-2"
        >
          Proceed to Validation
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}