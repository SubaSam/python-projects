import { useEffect, useState } from "react";
import { ArrowLeft, ArrowRight, Eye } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { InfoTooltip } from "@/components/metrics/InfoTooltip";
import { fetchCodegenMetrics } from "@/api/api";

interface ComponentItem {
  consolidated: number;
  generated: number;
  total_missing_count: number;
  total_extra_count: number;
  by_domain: Record<string, string[]>;
  missing_by_domain: Record<string, string[]>;
  extra_by_domain: Record<string, string[]>;
}

interface ApiResponse {
  components: {
    overall_summary: {
      total_consolidated: number;
      total_generated: number;
      total_missing: number;
      total_extra: number;
    };
    [key: string]: any;
  };
}

export default function CodeValidation() {
  const navigate = useNavigate();

  const [expandedRow, setExpandedRow] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [summary, setSummary] = useState<any>(null);
  const [tableRows, setTableRows] = useState<
    { key: string; label: string; data: ComponentItem }[]
  >([]);

  useEffect(() => {
    loadData();
  }, []);

 const loadData = async () => {
  try {
    setLoading(true);

    const saved =
      localStorage.getItem(
        "spec_upload_state"
      );

    const parsed = saved
      ? JSON.parse(saved)
      : null;

    const category =
      parsed?.category;

    if (!category) {
      setLoading(false);
      return;
    }

    const res =
      await fetchCodegenMetrics(
        category
      );

    console.log(
      "CODE VALIDATION:",
      res
    );

    const data: ApiResponse =
      res.response;

    const components =
      data.components;

    setSummary(
      components.overall_summary
    );

    const rows =
      Object.entries(
        components
      )
        .filter(
          ([key]) =>
            key !==
            "overall_summary"
        )
        .map(
          ([key, value]) => ({
            key,
            label:
              formatLabel(
                key
              ),
            data:
              value as ComponentItem,
          })
        );

    setTableRows(rows);
  } catch (error) {
    console.error(error);
  } finally {
    setLoading(false);
  }
};

  const formatLabel = (key: string) => {
    return key
      .replaceAll("_", " ")
      .replace(/\b\w/g, (c) => c.toUpperCase());
  };

  const renderDetails = (
    obj: Record<string, string[]>,
    type: string
  ) => {
    const entries = Object.entries(obj || {});

    if (!entries.length) {
      return (
        <div className="text-xs text-muted-foreground italic">
          No {type}
        </div>
      );
    }

    return (
      <div className="space-y-3">
        {entries.map(([service, values]) => (
          <div
            key={service}
            className="rounded-lg border border-border p-3"
          >
            <div className="text-xs font-semibold text-primary mb-2">
              {service}
            </div>

            <div className="space-y-1">
              {values.map((item, i) => (
                <div
                  key={i}
                  className="text-xs text-foreground"
                >
                  {item}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    );
  };

  if (loading) {
    return (
      <div className="p-10 text-center text-muted-foreground">
        Loading...
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex items-center gap-3">
        <button
          onClick={() => navigate("/codegen")}
          className="p-2 rounded-lg hover:bg-muted/50"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>

        <div>
          <h1 className="text-2xl font-bold text-foreground">
            Code Validation
          </h1>

          <p className="text-sm text-muted-foreground">
            Detailed validation of generated code against metadata specification
          </p>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="glass-card p-5 text-center">
          <div className="flex justify-center gap-2 mb-2">
            <span className="metric-label">
              Total Components
            </span>

            <InfoTooltip text="Expected total components from metadata." />
          </div>

          <div className="text-4xl font-black text-primary">
            {summary?.total_consolidated || 0}
          </div>
        </div>

        <div className="glass-card p-5 text-center">
          <div className="flex justify-center gap-2 mb-2">
            <span className="metric-label">
              Extracted
            </span>

            <InfoTooltip text="Successfully generated components." />
          </div>

          <div className="text-4xl font-black text-success">
            {summary?.total_generated || 0}
          </div>
        </div>

        <div className="glass-card p-5 text-center">
          <div className="flex justify-center gap-2 mb-2">
            <span className="metric-label">
              Missed
            </span>

            <InfoTooltip text="Components missing from output." />
          </div>

          <div className="text-4xl font-black text-destructive">
            {summary?.total_missing || 0}
          </div>
        </div>

        <div className="glass-card p-5 text-center">
          <div className="flex justify-center gap-2 mb-2">
            <span className="metric-label">
              Extra
            </span>

            <InfoTooltip text="Unexpected extra generated components." />
          </div>

          <div className="text-4xl font-black text-warning">
            {summary?.total_extra || 0}
          </div>
        </div>
      </div>

      {/* Validation Table */}
      <div className="glass-card overflow-hidden">
        <div className="p-4 border-b border-border/50 flex items-center gap-2">
          <span className="text-xs font-semibold tracking-widest text-muted-foreground uppercase">
            Component Validation Details
          </span>

          <InfoTooltip text="Per component breakdown with drill-down details." />
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-xs text-muted-foreground uppercase border-b border-border/30">
                <th className="text-left p-3 w-[28%]">
                  Component
                </th>
                <th className="text-center p-3 w-[12%]">
                  Total
                </th>
                <th className="text-center p-3 w-[12%]">
                  Extracted
                </th>
                <th className="text-center p-3 w-[12%]">
                  Missed
                </th>
                <th className="text-center p-3 w-[12%]">
                  Extra
                </th>
                <th className="text-center p-3 w-[24%]">
                  Actions
                </th>
              </tr>
            </thead>

            <tbody>
              {tableRows.map((row) => (
                <>
                  <tr
                    key={row.key}
                    className="border-b border-border/20 hover:bg-muted/20"
                  >
                    <td className="p-3 font-semibold text-foreground">
                      {row.label}
                    </td>

                    <td className="p-3 text-center font-bold">
                      {row.data.consolidated}
                    </td>

                    <td className="p-3 text-center font-bold text-success">
                      {row.data.generated}
                    </td>

                    <td className="p-3 text-center font-bold text-destructive">
                      {row.data.total_missing_count}
                    </td>

                    <td className="p-3 text-center font-bold text-warning">
                      {row.data.total_extra_count}
                    </td>

                    <td className="p-3 text-center">
                      <button
                        onClick={() =>
                          setExpandedRow(
                            expandedRow === row.key
                              ? null
                              : row.key
                          )
                        }
                        className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-medium text-primary hover:bg-primary/10"
                      >
                        <Eye className="w-3.5 h-3.5" />

                        {expandedRow === row.key
                          ? "Hide Details"
                          : "View Details"}
                      </button>
                    </td>
                  </tr>

                  {expandedRow === row.key && (
                    <tr>
                      <td
                        colSpan={6}
                        className="p-0"
                      >
                        <div className="bg-muted/20 px-6 py-4">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                              <h4 className="text-xs font-semibold text-destructive mb-3 uppercase">
                                Missing
                              </h4>

                              {renderDetails(
                                row.data.missing_by_domain,
                                "missing"
                              )}
                            </div>

                            <div>
                              <h4 className="text-xs font-semibold text-warning mb-3 uppercase">
                                Extra
                              </h4>

                              {renderDetails(
                                row.data.extra_by_domain,
                                "extra"
                              )}
                            </div>
                          </div>
                        </div>
                      </td>
                    </tr>
                  )}
                </>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Footer */}
      <div className="flex justify-between">
        <button
          onClick={() => navigate("/codegen")}
          className="px-6 py-2.5 rounded-lg border text-sm flex items-center gap-2"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Code Gen
        </button>

        <button
          onClick={() =>
            navigate("/completion")
          }
          className="px-6 py-2.5 rounded-lg bg-primary text-white text-sm flex items-center gap-2"
        >
          Finalize & Complete
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}