import {
  Upload,
  ArrowRight,
  ShieldCheck,
  X,
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useState, useRef, useEffect } from "react";

import {
  uploadServiceProject,
  fetchQualityReport,
  fetchSpecMetrics,
} from "@/api/api";

export default function SpecUpload() {
  const navigate = useNavigate();

  const [uploaded, setUploaded] = useState(false);
  const [specUploaded, setSpecUploaded] =
    useState(false);
  const [selectedFile, setSelectedFile] =
    useState<File | null>(null);
  const [fileName, setFileName] =
    useState<string | null>(null);

  // UI label = Technology
  // API param = category
  const [category, setCategory] =
    useState("");

  const [uploading, setUploading] =
    useState(false);
  const [qualityLoading, setQualityLoading] =
    useState(false);
  const [analyzed, setAnalyzed] =
    useState(false);
  const [error, setError] =
    useState<string | null>(null);

  const [specSummary, setSpecSummary] =
    useState<any>(null);

  const fileInputRef =
    useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    const saved =
      localStorage.getItem(
        "spec_upload_state"
      );

    if (saved) {
      const data = JSON.parse(saved);

      setSpecUploaded(
        data.specUploaded || false
      );
      setUploaded(
        data.specUploaded || false
      );
      setFileName(data.fileName || null);
      setAnalyzed(data.analyzed || false);
      setSpecSummary(
        data.specSummary || null
      );

      setCategory(data.category || "");
    }
  }, []);

  const persistState = (data: any) => {
    localStorage.setItem(
      "spec_upload_state",
      JSON.stringify(data)
    );
  };

  const SUMMARY_KEYS_BY_CATEGORY: Record<string, string[]> = {
  java: [
    "business_rules",
    "technical_validations",
    "db_tables",
    "error_codes",
  ],
  sas: [
    "pyspark_jobs",
    "business_rules",
    "data_quality_checks",
    "transformation_steps",
    "source_datasets",
    "output_datasets",
    "runtime_params",
    "exception_mappings",
  ],
};

  const handleSelectFile = () => {
    if (!category) {
      setError(
        "Please select technology first"
      );
      return;
    }

    fileInputRef.current?.click();
  };

  const handleFileChange = (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];

    if (!file) return;

    setSelectedFile(file);
    setFileName(file.name);
    setSpecUploaded(false);
    setUploaded(false);
    setAnalyzed(false);
    setSpecSummary(null);
    setError(null);
  };

  const handleDeleteFile = () => {
    setSelectedFile(null);
    setFileName(null);
    setSpecUploaded(false);
    setUploaded(false);
    setAnalyzed(false);
    setSpecSummary(null);
    setError(null);

    localStorage.removeItem(
      "spec_upload_state"
    );

    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleUpload = async () => {
    if (!selectedFile) return;

    try {
      setUploading(true);

      const res =
        await uploadServiceProject(
          selectedFile
        );

      if (
        res?.message ===
        "successfully uploaded"
      ) {
        setSpecUploaded(true);
        setUploaded(true);

        // API input = category
        const summary =
          await fetchSpecMetrics(
            category
          );

        setSpecSummary(summary);
        setAnalyzed(true);

        persistState({
          specUploaded: true,
          fileName,
          analyzed: true,
          specSummary: summary,
          category,
        });
      }
    } catch {
      setError("Upload failed");
    } finally {
      setUploading(false);
    }
  };

const handleProceed = async () => {
  try {
    setQualityLoading(true);

    const data =
      await fetchQualityReport(category);

    localStorage.setItem(
      "quality_data",
      JSON.stringify(data)
    );

    navigate("/qualifier");
  } catch (error) {
    console.error(error);
    setError("Failed to load qualifier data");
  } finally {
    setQualityLoading(false);
  }
};

// const getValueColor = (value: number) => {
//   if (value === 0) return "text-gray-400";
//   if (value < 5) return "text-green-600";
//   if (value < 15) return "text-yellow-500";
//   return "text-indigo-600";
// };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold">
          Specification Upload
        </h1>
      </div>

      {/* Dropdown */}
      <div className="glass-card p-3">
        <label className="block text-md font-medium mb-2 ml-3">
          Select Technology
        </label>

        <select
          value={category}
          onChange={(e) =>
            setCategory(
              e.target.value
            )
          }
          className="px-2 py-2 ml-5 rounded-md border bg-background"
        >
          <option value="">
            Select Technology
          </option>

          <option value="java">
            Java
          </option>

          <option value="sas">
            Pyspark
          </option>
        </select>
      </div>

      {/* Hidden File Input */}
      <input
        ref={fileInputRef}
        type="file"
        className="hidden"
        onChange={handleFileChange}
      />

      {/* Upload Card */}
      <div
        onClick={handleSelectFile}
        className="glass-card p-10 flex flex-col items-center justify-center gap-4 border-dashed border-2 cursor-pointer"
      >
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center">
          {specUploaded ? (
            <ShieldCheck className="w-8 h-8 text-success" />
          ) : (
            <Upload className="w-8 h-8 text-primary" />
          )}
        </div>

        {fileName ? (
          <div className="flex items-center gap-2">
            <p className="text-sm font-medium">
              {fileName}
            </p>

            <button
              onClick={(e) => {
                e.stopPropagation();
                handleDeleteFile();
              }}
              className="p-1 rounded hover:bg-red-100 text-red-500"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        ) : (
          <p className="text-sm font-medium">
            Drop specification file
            here or click to browse
          </p>
        )}

        {selectedFile &&
          !specUploaded && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                handleUpload();
              }}
              disabled={uploading}
              className="px-5 py-2 rounded-lg bg-primary text-primary-foreground text-sm"
            >
              {uploading
                ? "Uploading..."
                : "Upload"}
            </button>
          )}
      </div>

      {/* Error */}
      

{analyzed && specSummary && (
  <div className="space-y-6">
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {Object.entries(specSummary)
        .filter(([key, value]) => {
          const allowedKeys =
            SUMMARY_KEYS_BY_CATEGORY[category] || [];

          return (
            allowedKeys.includes(key) &&
            typeof value === "number"
          );
        })
        .map(([key, value]) => (
          <div
            key={key}
            className="glass-card p-6 text-center"
          >
            <p className="capitalize text-sm text-muted-foreground">
              {key.replaceAll("_", " ")}
            </p>

            <div className="text-5xl font-bold text-primary">
              {value}
            </div>
          </div>
        ))}
    </div>
  </div>
)}
      {/* Proceed */}
      {analyzed &&
        specSummary && (
          <div className="flex justify-end">
            <button
              onClick={
                handleProceed
              }
              disabled={
                qualityLoading
              }
              className="px-6 py-2.5 rounded-lg bg-primary text-primary-foreground font-semibold text-sm flex items-center gap-2"
            >
              {qualityLoading
                ? "Loading..."
                : "Proceed to Qualifier Analysis"}

              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}
        {error && (
        <div className="text-red-500 text-sm">
          {error}
        </div>
      )}
    </div>
  );
}