// API Base URL
const API_BASE_URL =
  import.meta.env.VITE_API_BASE_URL ||
  "http://10.73.89.251:8083";

// 🔹 Single Unified API
const CATEGORY_API = `${API_BASE_URL}/get-category-files`;

// ======================================================
// TYPES
// ======================================================

export interface ServiceMetrics {
  service: string;
  controllers: number;
  app_services: number;
  dtos: number;
  exceptions: number;
  endpoints: number;
  entities: number;
  repositories: number;
}

export interface MetricsResponse {
  summary: Record<string, number>;
  per_service: ServiceMetrics[];
}

// ======================================================
// UPLOAD MAIN PROJECT
// ======================================================

export const uploadServiceProject = async (
  file: File
) => {
  const formData = new FormData();
  formData.append("file", file);

  const res = await fetch(
    `${API_BASE_URL}/upload_file`,
    {
      method: "POST",
      body: formData,
    }
  );

  if (!res.ok)
    throw new Error("Upload failed");

  return res.json();
};

// ======================================================
// GENERIC FETCH CATEGORY
// ======================================================

const fetchCategoryFiles = async (
  technology: string
) => {
  const res = await fetch(CATEGORY_API, {
    method: "POST",
    headers: {
      "Content-Type":
        "application/json",
    },
    body: JSON.stringify({
      category:
        technology.toLowerCase(), // java / sas
    }),
  });

  if (!res.ok)
    throw new Error(
      `${technology} fetch failed`
    );

  return res.json();
};

// ======================================================
// GENERIC FILE RESPONSE EXTRACTOR
// ======================================================

// const getCategoryResponse = async (
//   technology: string,
//   fileKey: string
// ) => {
//   console.log("Technology:", technology);

//   const data =
//     await fetchCategoryFiles(technology);

//   console.log("Returned files:", data);

//   return (
//     data?.files?.[fileKey]?.response?.[0] || {}
//   );
// };
const getCategoryResponse = async (
  technology: string,
  fileKey: string
) => {
  console.log("Technology:", technology);

  const data = await fetchCategoryFiles(technology);

  console.log("Returned files:", data);

  return data || {};
};


// ======================================================
// METADATA METRICS
// ======================================================

export const fetchMetadataMetrics = async (technology: string) => {
  const result = await getCategoryResponse(
    technology,
    "metadata_metrics_output"
  );

  return result; // 👈 DON'T wrap again
};

// ======================================================
// CODEGEN METRICS
// ======================================================


export const fetchCodegenMetrics = async (technology: string) => {
  const result = await getCategoryResponse(
    technology,
    "code_metrics_output"
  );

  return result;}

// ======================================================
// METADATA FILES PREVIEW
// ======================================================

export const fetchMetadataFiles =
  async (technology: string) => {
    return await fetchCategoryFiles(
      technology
    );
  };

// ======================================================
// QUALITY REPORT
// ======================================================

export const fetchQualityReport =
  async (
    technology: string
  ) => {
    return getCategoryResponse(
      technology,
      "quality_checker_output"
    );
  };

// ======================================================
// SPEC METRICS
// ======================================================

// export const fetchSpecMetrics =
//   async (
//     technology: string
//   ) => {
//     const result =
//       await getCategoryResponse(
//         technology,
//         "spec_metrics_output"
//       );

//     return (
//       result.data?.summary || {}
//     );
//   };
export const fetchSpecMetrics = async (technology: string) => {
  const result = await fetchCategoryFiles(technology);

  return (
    result?.files?.spec_metrics_output?.response?.[0]?.data?.summary || {}
  );
};


// ======================================================
// METADATA VALIDATION
// ======================================================

export const fetchMetadataValidationFiles =
  async (
    technology: string
  ) => {
    return getCategoryResponse(
      technology,
      "metadata_validation_output"
    );
  };

// ======================================================
// ADDITIONAL DOCUMENTS UPLOAD
// ======================================================

export const uploadAdditionalDocuments =
  async (
    formData: FormData
  ) => {
    const res = await fetch(
      `${API_BASE_URL}/upload_additional_files`,
      {
        method: "POST",
        body: formData,
      }
    );

    if (!res.ok)
      throw new Error(
        "Additional documents upload failed"
      );

    return res.json();
  };

// ======================================================
// DOWNLOAD ZIP
// ======================================================

// ======================================================
// DOWNLOAD ZIP — JAVA
// ======================================================
export const downloadGeneratedZip = async () => {
  const res = await fetch(`${API_BASE_URL}/download-zip`, {
    method: "GET",
  });

  if (!res.ok) throw new Error("Download failed");
  return res.blob();
};

// ======================================================
// DOWNLOAD ZIP — SAS
// ======================================================
export const downloadGeneratedZipsas = async () => {
  const res = await fetch(`${API_BASE_URL}/download-zip-1`, {
    method: "GET",
  });

  if (!res.ok) throw new Error("Download failed");
  return res.blob();
};