from fastapi import FastAPI, UploadFile, File, Form
from pydantic import BaseModel
from typing import List, Dict
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
import os
from fastapi import HTTPException
from typing import Optional

app = FastAPI()

# -------------------------
# CORS
# -------------------------
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class ValidationMetrics(BaseModel):
    final_cov_score: int
    final_accuracy_score: int
# -------------------------
# Response Model
# -------------------------
class UsecaseResponse(BaseModel):
    returnCode: int
    returnMessage: str
    usecase_id: str
    usecase_name: str
    output_folder: str
    output_files: List[str]
    validation_score: Optional[Dict[str, ValidationMetrics]] = None
    # download_files: str   

# -------------------------
# Generate Spec API
# -------------------------
@app.post("/GenerateREspec", response_model=UsecaseResponse)
async def generate_REspec(
    usecase_id: str = Form(...),
    usecase_name: str = Form(...),
    technology_type: str = Form(...),
    input_folder: str = Form(...),
    logical_units_file: UploadFile = File(...)
):
    # Dummy response
    return {
        "returnCode": 0,
        "returnMessage": "success",
        "usecase_id": "scb_01",
        "usecase_name": "scb_1",
        "technology_type": "SAS",
        "output_folder": r"C:\Users\Subalakshmi\Desktop\PysparkCodeGeneration\Output\sas",
        "output_files": ["sas_1_spec.yaml", "sas_2_spec.yaml"],
        "validation_score": {
            "sas_1_spec":{
                "final_cov_score": 90,
                "final_accuracy_score": 85    
            },
            "sas_2_spec": {
                "final_cov_score": 70,
                "final_accuracy_score": 65    
            },
        },
    }

# -------------------------
# Download YAML API
# -------------------------

@app.post("/GenerateFEspec", response_model=UsecaseResponse)
async def generate_FEspec(
    usecase_id: str = Form(...),
    usecase_name: str = Form(...),
    technology_type: str = Form(...),
    logical_units_file: UploadFile = File(...)
):
    # Dummy response
    return {
        "returnCode": 0,
        "returnMessage": "success",
        "usecase_id":"scb_01",
        "usecase_name":"scb_scb",
        "output_folder":r"C:\Users\Subalakshmi\Desktop\PysparkCodeGeneration\Output\pyspark",
        "output_files": ["pyspark_1.py", "pyspark_2.py"],
        "validation_score": {
            "pyspark_1":{
                "final_cov_score": 90,
                "final_accuracy_score": 85    
            },
            "pyspark_2": {
                "final_cov_score": 70,
                "final_accuracy_score": 65    
            },
        },
    }   

@app.get("/DownloadFileRE/{program_type}/{filename}")
def download_file(filename: str):
    if not (filename.lower().endswith(".yaml") or filename.lower().endswith(".yml")):
        raise HTTPException(status_code=400, detail="Only YAML files are allowed for download.")

    folder = r"C:\Users\Subalakshmi\Desktop\PysparkCodeGeneration\Output\sas"
    file_path = os.path.join(folder, filename)

    if not os.path.isfile(file_path):
        raise HTTPException(status_code=404, detail="File not found")

    return FileResponse(
        path=file_path,
        filename=filename,
        media_type="application/x-yaml"
    )

@app.get("/DownloadFileFE/{program_type}/{filename}")
def download_file(filename: str):
    if not (filename.lower().endswith(".py")):
        raise HTTPException(status_code=400, detail="Only python(.py) files are allowed for download.")
    folder = r"C:\Users\Subalakshmi\Desktop\PysparkCodeGeneration\Output\pyspark"
    file_path = os.path.join(folder, filename)

    if not os.path.isfile(file_path):
        raise HTTPException(status_code=404, detail="File not found")

    return FileResponse(
        path=file_path,
        filename=filename,
        media_type="application/octet-python"
    )    

yaml_OUTPUT_FOLDER = r"C:\Users\Subalakshmi\Desktop\PysparkCodeGeneration\Output\sas"
@app.get("/ViewFileRE/{program_type}/{filename}")
def view_file(filename: str):
    # ---- Security: prevent ../ attacks ----
    if not (filename.lower().endswith(".yaml") or filename.lower().endswith(".yml")):
        raise HTTPException(status_code=400, detail="Only YAML files are allowed for view.")

    file_path = os.path.join(yaml_OUTPUT_FOLDER, filename)

    if not os.path.isfile(file_path):
        raise HTTPException(status_code=404, detail="File not found")

    try:
        with open(file_path, "r", encoding="utf-8") as f:
            content = f.read()

        return {
            "filename": filename,
            "content": content
        }

    except UnicodeDecodeError:
        raise HTTPException(
            status_code=400,
            detail="File is not a text-readable format"
        )
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=str(e)
        )


PYSPARK_OUTPUT_FOLDER = r"C:\Users\Subalakshmi\Desktop\PysparkCodeGeneration\Output\pyspark"
@app.get("/ViewFileFE/{program_type}/{filename}")
def view_file(filename: str):
    if not (filename.lower().endswith(".py")):
        raise HTTPException(status_code=400, detail="Only python(.py) files are allowed for view.")

    file_path = os.path.join(PYSPARK_OUTPUT_FOLDER, filename)

    if not os.path.isfile(file_path):
        raise HTTPException(status_code=404, detail="File not found")

    try:
        with open(file_path, "r", encoding="utf-8") as f:
            content = f.read()

        return {
            "filename": filename,
            "content": content
        }

    except UnicodeDecodeError:
        raise HTTPException(
            status_code=400,
            detail="File is not a text-readable format"
        )
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=str(e)
        )        