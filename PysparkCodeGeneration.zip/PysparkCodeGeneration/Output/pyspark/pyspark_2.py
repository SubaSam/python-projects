# ecommerce_customer_analytics.py
"""
PySpark script for e-commerce customer analytics
Includes RFM analysis, customer segmentation, product recommendations, and churn prediction
"""

from pyspark.sql import SparkSession
from pyspark.sql.functions import (
    col, when, sum as _sum, avg, count, max as _max, min as _min,
    datediff, current_date, lit, concat_ws, md5, window,
    lag, lead, row_number, rank, dense_rank, percent_rank,
    explode, array, collect_list, collect_set, size, array_distinct,
    regexp_replace, trim, upper, lower, split, concat,
    year, month, dayofmonth, hour, to_date, months_between,
    udf, pandas_udf, broadcast, coalesce, desc, asc, first, last
)
from pyspark.sql.window import Window
from pyspark.sql.types import (
    StructType, StructField, StringType, DoubleType, 
    IntegerType, TimestampType, DateType, BooleanType, 
    ArrayType, FloatType
)
from pyspark.ml.feature import (
    VectorAssembler, StandardScaler, StringIndexer, 
    OneHotEncoder, Bucketizer
)
from pyspark.ml.clustering import KMeans
from pyspark.ml.recommendation import ALS
from pyspark.ml.classification import GBTClassifier
from pyspark.ml import Pipeline
from pyspark.ml.evaluation import BinaryClassificationEvaluator
import logging
from datetime import datetime, timedelta
import numpy as np

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class EcommerceCustomerAnalytics:
    """
    Comprehensive e-commerce customer analytics pipeline
    """
    
    def __init__(self, app_name="EcommerceAnalytics"):
        """Initialize Spark session with optimizations"""
        self.spark = SparkSession.builder \
            .appName(app_name) \
            .config("spark.sql.adaptive.enabled", "true") \
            .config("spark.sql.adaptive.coalescePartitions.enabled", "true") \
            .config("spark.sql.shuffle.partitions", "200") \
            .config("spark.sql.autoBroadcastJoinThreshold", "10485760") \
            .config("spark.sql.broadcastTimeout", "600") \
            .config("spark.driver.memory", "4g") \
            .config("spark.executor.memory", "4g") \
            .getOrCreate()
        
        self.spark.sparkContext.setLogLevel("WARN")
        logger.info(f"Spark session created: {app_name}")
        
        # Define analysis date (usually current date or specific date)
        self.analysis_date = current_date()
    
    def load_data(self, orders_path, order_items_path, customers_path, products_path):
        """
        Load all required datasets
        
        Args:
            orders_path: Path to orders data
            order_items_path: Path to order items data
            customers_path: Path to customer data
            products_path: Path to product data
        
        Returns:
            Tuple of DataFrames (orders, order_items, customers, products)
        """
        logger.info("Loading datasets")
        
        orders = self.spark.read.parquet(orders_path)
        order_items = self.spark.read.parquet(order_items_path)
        customers = self.spark.read.parquet(customers_path)
        products = self.spark.read.parquet(products_path)
        
        logger.info(f"Loaded orders: {orders.count()}")
        logger.info(f"Loaded order items: {order_items.count()}")
        logger.info(f"Loaded customers: {customers.count()}")
        logger.info(f"Loaded products: {products.count()}")
        
        return orders, order_items, customers, products
    
    def prepare_transaction_data(self, orders, order_items, products):
        """
        Join and prepare transaction-level data
        
        Args:
            orders: Orders DataFrame
            order_items: Order items DataFrame
            products: Products DataFrame
        
        Returns:
            Transaction DataFrame with all details
        """
        logger.info("Preparing transaction data")
        
        # Join orders with order items
        transactions = orders.join(
            order_items,
            "order_id",
            "inner"
        )
        
        # Join with products
        transactions = transactions.join(
            broadcast(products),
            "product_id",
            "left"
        )
        
        # Calculate line total
        transactions = transactions.withColumn(
            "line_total",
            col("quantity") * col("unit_price")
        )
        
        # Add time-based features
        transactions = transactions.withColumn(
            "order_year",
            year("order_date")
        )
        transactions = transactions.withColumn(
            "order_month",
            month("order_date")
        )
        transactions = transactions.withColumn(
            "order_day_of_week",
            date_format("order_date", "EEEE")
        )
        
        return transactions
    
    def rfm_analysis(self, transactions):
        """
        Calculate RFM (Recency, Frequency, Monetary) scores
        
        Args:
            transactions: Transaction DataFrame
        
        Returns:
            DataFrame with RFM scores and segments
        """
        logger.info("Performing RFM analysis")
        
        # Calculate RFM metrics
        rfm = transactions.groupBy("customer_id").agg(
            datediff(self.analysis_date, _max("order_date")).alias("recency"),
            count("order_id").alias("frequency"),
            _sum("line_total").alias("monetary")
        )
        
        # Calculate RFM scores using quantiles
        # Recency: Lower is better (inverse scoring)
        recency_quantiles = rfm.stat.approxQuantile("recency", [0.2, 0.4, 0.6, 0.8], 0.01)
        rfm = rfm.withColumn(
            "r_score",
            when(col("recency") <= recency_quantiles[0], 5)
            .when(col("recency") <= recency_quantiles[1], 4)
            .when(col("recency") <= recency_quantiles[2], 3)
            .when(col("recency") <= recency_quantiles[3], 2)
            .otherwise(1)
        )
        
        # Frequency: Higher is better
        frequency_quantiles = rfm.stat.approxQuantile("frequency", [0.2, 0.4, 0.6, 0.8], 0.01)
        rfm = rfm.withColumn(
            "f_score",
            when(col("frequency") <= frequency_quantiles[0], 1)
            .when(col("frequency") <= frequency_quantiles[1], 2)
            .when(col("frequency") <= frequency_quantiles[2], 3)
            .when(col("frequency") <= frequency_quantiles[3], 4)
            .otherwise(5)
        )
        
        # Monetary: Higher is better
        monetary_quantiles = rfm.stat.approxQuantile("monetary", [0.2, 0.4, 0.6, 0.8], 0.01)
        rfm = rfm.withColumn(
            "m_score",
            when(col("monetary") <= monetary_quantiles[0], 1)
            .when(col("monetary") <= monetary_quantiles[1], 2)
            .when(col("monetary") <= monetary_quantiles[2], 3)
            .when(col("monetary") <= monetary_quantiles[3], 4)
            .otherwise(5)
        )
        
        # Calculate RFM composite score
        rfm = rfm.withColumn(
            "rfm_score",
            concat(col("r_score"), col("f_score"), col("m_score"))
        )
        
        # RFM Segmentation
        rfm = rfm.withColumn(
            "customer_segment",
            when((col("r_score") >= 4) & (col("f_score") >= 4) & (col("m_score") >= 4), "Champions")
            .when((col("r_score") >= 3) & (col("f_score") >= 4) & (col("m_score") >= 4), "Loyal Customers")
            .when((col("r_score") >= 4) & (col("f_score") <= 2) & (col("m_score") <= 2), "New Customers")
            .when((col("r_score") >= 3) & (col("f_score") <= 2) & (col("m_score") <= 2), "Promising")
            .when((col("r_score") >= 3) & (col("f_score") >= 3) & (col("m_score") >= 3), "Potential Loyalist")
            .when((col("r_score") <= 2) & (col("f_score") >= 3) & (col("m_score") >= 3), "At Risk")
            .when((col("r_score") <= 2) & (col("f_score") <= 2) & (col("m_score") >= 3), "Cant Lose Them")
            .when((col("r_score") <= 2) & (col("f_score") >= 2), "Hibernating")
            .otherwise("Lost")
        )
        
        # Calculate CLV estimate (simple version)
        rfm = rfm.withColumn(
            "estimated_clv",
            (col("monetary") / col("frequency")) * col("frequency") * 12  # Annual estimate
        )
        
        # Log segment distribution
        segment_dist = rfm.groupBy("customer_segment").count().orderBy(desc("count"))
        logger.info("RFM Segment Distribution:")
        for row in segment_dist.collect():
            logger.info(f"  {row['customer_segment']}: {row['count']}")
        
        return rfm
    
    def customer_behavior_metrics(self, transactions):
        """
        Calculate detailed customer behavior metrics
        
        Args:
            transactions: Transaction DataFrame
        
        Returns:
            DataFrame with behavioral metrics
        """
        logger.info("Calculating customer behavior metrics")
        
        # Overall customer metrics
        customer_metrics = transactions.groupBy("customer_id").agg(
            # Purchase behavior
            count("order_id").alias("total_orders"),
            _sum("line_total").alias("total_revenue"),
            avg("line_total").alias("avg_order_value"),
            _sum("quantity").alias("total_items_purchased"),
            avg("quantity").alias("avg_items_per_order"),
            
            # Product diversity
            count(col("product_id").distinct()).alias("unique_products"),
            count(col("category").distinct()).alias("unique_categories"),
            
            # Temporal behavior
            _min("order_date").alias("first_purchase_date"),
            _max("order_date").alias("last_purchase_date"),
            
            # Channel behavior
            count(when(col("order_channel") == "web", 1)).alias("web_orders"),
            count(when(col("order_channel") == "mobile", 1)).alias("mobile_orders"),
            count(when(col("order_channel") == "store", 1)).alias("store_orders"),
            
            # Payment behavior
            count(when(col("payment_method") == "credit_card", 1)).alias("credit_card_payments"),
            count(when(col("payment_method") == "debit_card", 1)).alias("debit_card_payments"),
            count(when(col("payment_method") == "digital_wallet", 1)).alias("digital_wallet_payments"),
            
            # Discount behavior
            _sum(when(col("discount_applied") > 0, 1).otherwise(0)).alias("orders_with_discount"),
            avg("discount_applied").alias("avg_discount_used")
        )
        
        # Calculate customer tenure
        customer_metrics = customer_metrics.withColumn(
            "customer_tenure_days",
            datediff(col("last_purchase_date"), col("first_purchase_date"))
        )
        
        # Calculate purchase frequency (orders per month)
        customer_metrics = customer_metrics.withColumn(
            "purchase_frequency_monthly",
            col("total_orders") / (col("customer_tenure_days") / 30.0)
        )
        
        # Calculate preferred channel
        customer_metrics = customer_metrics.withColumn(
            "preferred_channel",
            when(col("web_orders") >= col("mobile_orders"), 
                 when(col("web_orders") >= col("store_orders"), "web")
                 .otherwise("store"))
            .otherwise(
                when(col("mobile_orders") >= col("store_orders"), "mobile")
                .otherwise("store")
            )
        )
        
        # Calculate product exploration score
        customer_metrics = customer_metrics.withColumn(
            "product_exploration_score",
            (col("unique_products") / col("total_orders")) * 100
        )
        
        return customer_metrics
    
    def product_affinity_analysis(self, transactions):
        """
        Analyze product affinity and create recommendation candidates
        
        Args:
            transactions: Transaction DataFrame
        
        Returns:
            Product affinity DataFrame
        """
        logger.info("Analyzing product affinity")
        
        # Create customer-product pairs
        customer_products = transactions.groupBy("customer_id", "product_id").agg(
            _sum("quantity").alias("total_quantity"),
            count("order_id").alias("purchase_count"),
            _max("order_date").alias("last_purchase_date")
        )
        
        # Create product co-occurrence matrix
        # Products bought together in same order
        order_products = transactions.groupBy("order_id").agg(
            collect_list("product_id").alias("products_in_order")
        )
        
        # Calculate product pairs
        from pyspark.sql.functions import explode as spark_explode
        
        # Self-join to get product pairs
        product_pairs = order_products.select(
            "order_id",
            spark_explode("products_in_order").alias("product_a")
        ).join(
            order_products.select(
                "order_id",
                spark_explode("products_in_order").alias("product_b")
            ),
            "order_id"
        ).filter(col("product_a") < col("product_b"))  # Avoid duplicates
        
        # Calculate co-occurrence frequency
        product_affinity = product_pairs.groupBy("product_a", "product_b").agg(
            count("*").alias("co_occurrence_count")
        )
        
        # Calculate support (what % of orders contain both products)
        total_orders = transactions.select("order_id").distinct().count()
        product_affinity = product_affinity.withColumn(
            "support",
            col("co_occurrence_count") / total_orders
        )
        
        # Filter by minimum support threshold
        product_affinity = product_affinity.filter(col("support") >= 0.01)  # 1% threshold
        
        # Rank product pairs
        window_spec = Window.orderBy(desc("co_occurrence_count"))
        product_affinity = product_affinity.withColumn(
            "affinity_rank",
            row_number().over(window_spec)
        )
        
        logger.info(f"Found {product_affinity.count()} product affinity pairs")
        
        return product_affinity, customer_products
    
    def build_recommendation_model(self, customer_products):
        """
        Build collaborative filtering recommendation model using ALS
        
        Args:
            customer_products: Customer-product interaction DataFrame
        
        Returns:
            Trained ALS model and recommendations
        """
        logger.info("Building recommendation model")
        
        # Create user and item indices
        customer_indexer = StringIndexer(
            inputCol="customer_id",
            outputCol="customer_index"
        ).fit(customer_products)
        
        product_indexer = StringIndexer(
            inputCol="product_id",
            outputCol="product_index"
        ).fit(customer_products)
        
        # Transform data
        indexed_data = customer_indexer.transform(customer_products)
        indexed_data = product_indexer.transform(indexed_data)
        
        # Split data for validation
        train_data, test_data = indexed_data.randomSplit([0.8, 0.2], seed=42)
        
        # Build ALS model
        als = ALS(
            maxIter=10,
            regParam=0.1,
            userCol="customer_index",
            itemCol="product_index",
            ratingCol="purchase_count",
            coldStartStrategy="drop",
            nonnegative=True
        )
        
        model = als.fit(train_data)
        
        # Generate recommendations for all customers
        customer_recs = model.recommendForAllUsers(10)
        
        # Transform back to original IDs
        customer_recs = customer_recs.join(
            customer_indexer.transform(
                customer_products.select("customer_id").distinct()
            ),
            customer_recs.user == col("customer_index")
        ).select("customer_id", "recommendations")
        
        logger.info("Recommendation model built successfully")
        
        return model, customer_recs
    
    def churn_prediction_features(self, rfm, customer_metrics):
        """
        Prepare features for churn prediction
        
        Args:
            rfm: RFM DataFrame
            customer_metrics: Customer behavior metrics DataFrame
        
        Returns:
            DataFrame with churn features and labels
        """
        logger.info("Preparing churn prediction features")
        
        # Join RFM and metrics
        churn_data = rfm.join(customer_metrics, "customer_id")
        
        # Define churn (e.g., no purchase in last 60 days)
        churn_data = churn_data.withColumn(
            "is_churned",
            when(col("recency") > 60, 1).otherwise(0)
        )
        
        # Create additional features
        churn_data = churn_data.withColumn(
            "avg_days_between_orders",
            col("customer_tenure_days") / col("total_orders")
        )
        
        churn_data = churn_data.withColumn(
            "revenue_trend",
            col("monetary") / (col("customer_tenure_days") + 1)
        )
        
        churn_data = churn_data.withColumn(
            "engagement_score",
            (col("f_score") * col("m_score")) / 25.0  # Normalized
        )
        
        # Log churn rate
        churn_rate = churn_data.filter(col("is_churned") == 1).count() / churn_data.count() * 100
        logger.info(f"Current churn rate: {churn_rate:.2f}%")
        
        return churn_data
    
    def customer_lifetime_value(self, transactions, rfm):
        """
        Calculate Customer Lifetime Value (CLV)
        
        Args:
            transactions: Transaction DataFrame
            rfm: RFM DataFrame
        
        Returns:
            DataFrame with CLV calculations
        """
        logger.info("Calculating Customer Lifetime Value")
        
        # Calculate monthly cohorts
        cohort_data = transactions.withColumn(
            "cohort_month",
            date_format("order_date", "yyyy-MM")
        ).withColumn(
            "first_purchase_month",
            date_format(
                _min("order_date").over(Window.partitionBy("customer_id")),
                "yyyy-MM"
            )
        )
        
        # Calculate months since first purchase
        cohort_data = cohort_data.withColumn(
            "months_since_first_purchase",
            months_between(col("order_date"), col("first_purchase_month"))
        )
        
        # Aggregate by cohort and month
        cohort_analysis = cohort_data.groupBy(
            "customer_id",
            "first_purchase_month",
            "months_since_first_purchase"
        ).agg(
            _sum("line_total").alias("monthly_revenue")
        )
        
        # Calculate cumulative revenue
        window_spec = Window.partitionBy("customer_id").orderBy("months_since_first_purchase")
        cohort_analysis = cohort_analysis.withColumn(
            "cumulative_revenue",
            _sum("monthly_revenue").over(window_spec)
        )
        
        # Join with RFM for CLV prediction
        clv = rfm.join(
            cohort_analysis.groupBy("customer_id").agg(
                _max("cumulative_revenue").alias("historical_clv"),
                _max("months_since_first_purchase").alias("customer_age_months")
            ),
            "customer_id"
        )
        
        # Predict future CLV (simplified model)
        clv = clv.withColumn(
            "predicted_clv_12_months",
            when(col("customer_age_months") > 0,
                 (col("historical_clv") / col("customer_age_months")) * 12
            ).otherwise(col("monetary"))
        )
        
        clv = clv.withColumn(
            "clv_segment",
            when(col("predicted_clv_12_months") > 10000, "Very High")
            .when(col("predicted_clv_12_months") > 5000, "High")
            .when(col("predicted_clv_12_months") > 1000, "Medium")
            .otherwise("Low")
        )
        
        return clv
    
    def cohort_retention_analysis(self, transactions):
        """
        Perform cohort-based retention analysis
        
        Args:
            transactions: Transaction DataFrame
        
        Returns:
            Cohort retention DataFrame
        """
        logger.info("Performing cohort retention analysis")
        
        # Identify first purchase month for each customer
        first_purchase = transactions.groupBy("customer_id").agg(
            date_format(_min("order_date"), "yyyy-MM").alias("cohort_month")
        )
        
        # Join back to transactions
        cohort_data = transactions.join(first_purchase, "customer_id")
        
        # Calculate months since cohort
        cohort_data = cohort_data.withColumn(
            "order_month",
            date_format("order_date", "yyyy-MM")
        )
        
        cohort_data = cohort_data.withColumn(
            "months_since_cohort",
            months_between(col("order_date"), col("cohort_month"))
        )
        
        # Calculate retention metrics
        cohort_retention = cohort_data.groupBy(
            "cohort_month",
            "months_since_cohort"
        ).agg(
            count(col("customer_id").distinct()).alias("active_customers"),
            _sum("line_total").alias("cohort_revenue")
        )
        
        # Calculate cohort size
        cohort_size = first_purchase.groupBy("cohort_month").agg(
            count("customer_id").alias("cohort_size")
        )
        
        # Join and calculate retention rate
        cohort_retention = cohort_retention.join(cohort_size, "cohort_month")
        cohort_retention = cohort_retention.withColumn(
            "retention_rate",
            (col("active_customers") / col("cohort_size")) * 100
        )
        
        cohort_retention = cohort_retention.withColumn(
            "revenue_per_customer",
            col("cohort_revenue") / col("active_customers")
        )
        
        return cohort_retention
    
    def save_results(self, df, output_path, partition_by=None):
        """
        Save processed data with optional partitioning
        
        Args:
            df: DataFrame to save
            output_path: Output location
            partition_by: Column(s) to partition by
        """
        logger.info(f"Saving results to {output_path}")
        
        writer = df.write.mode("overwrite")
        
        if partition_by:
            writer = writer.partitionBy(partition_by)
        
        writer.parquet(output_path)
        logger.info(f"Successfully saved {df.count()} records")
    
    def run_full_pipeline(self, orders_path, order_items_path, customers_path, 
                         products_path, output_base_path):
        """
        Run the complete analytics pipeline
        
        Args:
            orders_path: Path to orders data
            order_items_path: Path to order items data
            customers_path: Path to customer data
            products_path: Path to product data
            output_base_path: Base path for all outputs
        """
        logger.info("=" * 80)
        logger.info("Starting E-Commerce Customer Analytics Pipeline")
        logger.info("=" * 80)
        
        try:
            # Load data
            orders, order_items, customers, products = self.load_data(
                orders_path, order_items_path, customers_path, products_path
            )
            
            # Prepare transactions
            transactions = self.prepare_transaction_data(orders, order_items, products)
            transactions.cache()
            
            # Save prepared transactions
            self.save_results(
                transactions,
                f"{output_base_path}/prepared_transactions",
                partition_by=["order_year", "order_month"]
            )
            
            # RFM Analysis
            rfm = self.rfm_analysis(transactions)
            self.save_results(rfm, f"{output_base_path}/rfm_analysis")
            
            # Customer Behavior Metrics
            customer_metrics = self.customer_behavior_metrics(transactions)
            self.save_results(customer_metrics, f"{output_base_path}/customer_metrics")
            
            # Product Affinity Analysis
            product_affinity, customer_products = self.product_affinity_analysis(transactions)
            self.save_results(product_affinity, f"{output_base_path}/product_affinity")
            
            # Build Recommendation Model
            model, recommendations = self.build_recommendation_model(customer_products)
            self.save_results(recommendations, f"{output_base_path}/product_recommendations")
            
            # Churn Prediction Features
            churn_data = self.churn_prediction_features(rfm, customer_metrics)
            self.save_results(churn_data, f"{output_base_path}/churn_features")
            
            # Customer Lifetime Value
            clv = self.customer_lifetime_value(transactions, rfm)
            self.save_results(clv, f"{output_base_path}/customer_lifetime_value")
            
            # Cohort Retention Analysis
            cohort_retention = self.cohort_retention_analysis(transactions)
            self.save_results(cohort_retention, f"{output_base_path}/cohort_retention")
            
            # Unpersist cached data
            transactions.unpersist()
            
            logger.info("=" * 80)
            logger.info("Pipeline completed successfully!")
            logger.info("=" * 80)
            
        except Exception as e:
            logger.error(f"Pipeline failed: {str(e)}", exc_info=True)
            raise
        finally:
            self.spark.stop()


def main():
    """Main execution function"""
    # Configuration
    ORDERS_PATH = "C:/114002/input/sas/orders"
    ORDER_ITEMS_PATH = "C:/114002/input/sas/order_items"
    CUSTOMERS_PATH = "C:/114002/input/sas/customers"
    PRODUCTS_PATH = "C:/114002/input/sas/products"
    OUTPUT_PATH = "C:/114002/output/sas/ecommerce_analytics"
    
    # Initialize analytics processor
    analytics = EcommerceCustomerAnalytics()
    
    # Run full pipeline
    analytics.run_full_pipeline(
        ORDERS_PATH,
        ORDER_ITEMS_PATH,
        CUSTOMERS_PATH,
        PRODUCTS_PATH,
        OUTPUT_PATH
    )


if __name__ == "__main__":
    main()