# banking_transaction_processor.py
"""
PySpark script for processing banking transactions
Includes fraud detection, customer analytics, and transaction aggregation
"""

from pyspark.sql import SparkSession
from pyspark.sql.functions import (
    col, when, sum as _sum, avg, count, max as _max, min as _min,
    datediff, current_date, lit, concat_ws, md5, window,
    lag, lead, row_number, rank, dense_rank, explode, array,
    regexp_replace, trim, upper, lower, split, size,
    year, month, dayofmonth, hour, minute, date_format,
    udf, pandas_udf, broadcast, coalesce
)
from pyspark.sql.window import Window
from pyspark.sql.types import (
    StructType, StructField, StringType, DoubleType, 
    IntegerType, TimestampType, DateType, BooleanType, ArrayType
)
from pyspark.ml.feature import VectorAssembler, StandardScaler
from pyspark.ml.classification import RandomForestClassifier
from pyspark.ml import Pipeline
import logging
from datetime import datetime, timedelta

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class BankingTransactionProcessor:
    """
    Process banking transactions with fraud detection and analytics
    """
    
    def __init__(self, app_name="BankingTransactionProcessor"):
        """Initialize Spark session"""
        self.spark = SparkSession.builder \
            .appName(app_name) \
            .config("spark.sql.adaptive.enabled", "true") \
            .config("spark.sql.adaptive.coalescePartitions.enabled", "true") \
            .config("spark.sql.shuffle.partitions", "200") \
            .config("spark.sql.autoBroadcastJoinThreshold", "10485760") \
            .getOrCreate()
        
        self.spark.sparkContext.setLogLevel("WARN")
        logger.info(f"Spark session created: {app_name}")
    
    def define_transaction_schema(self):
        """Define schema for transaction data"""
        return StructType([
            StructField("transaction_id", StringType(), False),
            StructField("account_id", StringType(), False),
            StructField("customer_id", StringType(), False),
            StructField("transaction_date", TimestampType(), False),
            StructField("transaction_amount", DoubleType(), False),
            StructField("transaction_type", StringType(), False),
            StructField("merchant_id", StringType(), True),
            StructField("merchant_category", StringType(), True),
            StructField("transaction_channel", StringType(), False),
            StructField("card_number", StringType(), True),
            StructField("location_city", StringType(), True),
            StructField("location_country", StringType(), True),
            StructField("device_id", StringType(), True),
            StructField("ip_address", StringType(), True),
            StructField("is_international", BooleanType(), False)
        ])
    
    def load_transactions(self, input_path, file_format="parquet"):
        """
        Load transaction data from various sources
        
        Args:
            input_path: Path to transaction data
            file_format: Format of input file (parquet, csv, json)
        
        Returns:
            DataFrame with transactions
        """
        logger.info(f"Loading transactions from {input_path}")
        
        if file_format == "csv":
            df = self.spark.read \
                .option("header", "true") \
                .option("inferSchema", "true") \
                .csv(input_path)
        elif file_format == "json":
            df = self.spark.read.json(input_path)
        else:  # parquet
            df = self.spark.read.parquet(input_path)
        
        logger.info(f"Loaded {df.count()} transactions")
        return df
    
    def data_quality_checks(self, df):
        """
        Perform data quality checks on transactions
        
        Args:
            df: Input DataFrame
        
        Returns:
            Cleaned DataFrame with quality metrics
        """
        logger.info("Performing data quality checks")
        
        # Remove duplicates
        initial_count = df.count()
        df = df.dropDuplicates(["transaction_id"])
        duplicates_removed = initial_count - df.count()
        
        # Handle null values
        null_counts = df.select([
            _sum(when(col(c).isNull(), 1).otherwise(0)).alias(c)
            for c in df.columns
        ]).collect()[0].asDict()
        
        logger.info(f"Removed {duplicates_removed} duplicate transactions")
        logger.info(f"Null values per column: {null_counts}")
        
        # Fill null values with defaults
        df = df.fillna({
            "merchant_id": "UNKNOWN",
            "merchant_category": "UNKNOWN",
            "location_city": "UNKNOWN",
            "location_country": "UNKNOWN",
            "device_id": "UNKNOWN",
            "ip_address": "0.0.0.0"
        })
        
        # Validate amount is positive
        df = df.filter(col("transaction_amount") > 0)
        
        # Add quality score
        df = df.withColumn(
            "data_quality_score",
            when(col("merchant_id") != "UNKNOWN", 20).otherwise(0) +
            when(col("location_city") != "UNKNOWN", 20).otherwise(0) +
            when(col("device_id") != "UNKNOWN", 20).otherwise(0) +
            when(col("card_number").isNotNull(), 20).otherwise(0) +
            when(col("ip_address") != "0.0.0.0", 20).otherwise(0)
        )
        
        return df
    
    def feature_engineering(self, df):
        """
        Create features for fraud detection and analytics
        
        Args:
            df: Input DataFrame
        
        Returns:
            DataFrame with engineered features
        """
        logger.info("Engineering features")
        
        # Time-based features
        df = df.withColumn("transaction_hour", hour("transaction_date")) \
               .withColumn("transaction_day", dayofmonth("transaction_date")) \
               .withColumn("transaction_month", month("transaction_date")) \
               .withColumn("transaction_year", year("transaction_date")) \
               .withColumn("day_of_week", date_format("transaction_date", "EEEE"))
        
        # Amount-based features
        df = df.withColumn(
            "amount_category",
            when(col("transaction_amount") < 50, "small")
            .when(col("transaction_amount") < 500, "medium")
            .when(col("transaction_amount") < 5000, "large")
            .otherwise("very_large")
        )
        
        df = df.withColumn("log_amount", log(col("transaction_amount") + 1))
        
        # Velocity features (transactions per customer in last hour)
        window_spec = Window.partitionBy("customer_id") \
                            .orderBy("transaction_date") \
                            .rangeBetween(-3600, 0)  # Last hour in seconds
        
        df = df.withColumn(
            "txn_count_last_hour",
            count("*").over(window_spec) - 1  # Exclude current transaction
        )
        
        df = df.withColumn(
            "total_amount_last_hour",
            _sum("transaction_amount").over(window_spec) - col("transaction_amount")
        )
        
        # Time since last transaction
        customer_window = Window.partitionBy("customer_id").orderBy("transaction_date")
        df = df.withColumn(
            "prev_transaction_time",
            lag("transaction_date").over(customer_window)
        )
        
        df = df.withColumn(
            "seconds_since_last_txn",
            when(
                col("prev_transaction_time").isNotNull(),
                (col("transaction_date").cast("long") - 
                 col("prev_transaction_time").cast("long"))
            ).otherwise(999999)
        )
        
        # Unusual patterns
        df = df.withColumn(
            "is_odd_hour",
            when((col("transaction_hour") >= 0) & (col("transaction_hour") < 6), True)
            .otherwise(False)
        )
        
        df = df.withColumn(
            "is_round_amount",
            when(col("transaction_amount") % 100 == 0, True).otherwise(False)
        )
        
        return df
    
    def detect_fraud(self, df):
        """
        Apply rule-based fraud detection
        
        Args:
            df: Input DataFrame with features
        
        Returns:
            DataFrame with fraud indicators
        """
        logger.info("Detecting fraudulent transactions")
        
        # Rule-based fraud detection
        df = df.withColumn(
            "fraud_score",
            # High amount transactions
            when(col("transaction_amount") > 10000, 25).otherwise(0) +
            # Multiple transactions in short time
            when(col("txn_count_last_hour") > 5, 20).otherwise(0) +
            # Large total amount in short time
            when(col("total_amount_last_hour") > 20000, 20).otherwise(0) +
            # Odd hours
            when(col("is_odd_hour"), 15).otherwise(0) +
            # International transactions
            when(col("is_international"), 10).otherwise(0) +
            # Very quick successive transactions
            when(col("seconds_since_last_txn") < 60, 10).otherwise(0)
        )
        
        df = df.withColumn(
            "fraud_risk_level",
            when(col("fraud_score") >= 60, "critical")
            .when(col("fraud_score") >= 40, "high")
            .when(col("fraud_score") >= 20, "medium")
            .otherwise("low")
        )
        
        df = df.withColumn(
            "requires_review",
            when(col("fraud_score") >= 40, True).otherwise(False)
        )
        
        # Log fraud statistics
        fraud_stats = df.groupBy("fraud_risk_level").count().collect()
        logger.info("Fraud risk distribution:")
        for row in fraud_stats:
            logger.info(f"  {row['fraud_risk_level']}: {row['count']}")
        
        return df
    
    def customer_aggregations(self, df):
        """
        Create customer-level aggregations
        
        Args:
            df: Transaction DataFrame
        
        Returns:
            Customer analytics DataFrame
        """
        logger.info("Computing customer aggregations")
        
        customer_agg = df.groupBy("customer_id").agg(
            count("transaction_id").alias("total_transactions"),
            _sum("transaction_amount").alias("total_spent"),
            avg("transaction_amount").alias("avg_transaction_amount"),
            _max("transaction_amount").alias("max_transaction_amount"),
            _min("transaction_amount").alias("min_transaction_amount"),
            _max("transaction_date").alias("last_transaction_date"),
            _min("transaction_date").alias("first_transaction_date"),
            _sum(when(col("fraud_risk_level") == "critical", 1).otherwise(0))
                .alias("critical_fraud_alerts"),
            _sum(when(col("fraud_risk_level") == "high", 1).otherwise(0))
                .alias("high_fraud_alerts"),
            avg("fraud_score").alias("avg_fraud_score"),
            # Channel preferences
            _sum(when(col("transaction_channel") == "online", 1).otherwise(0))
                .alias("online_transactions"),
            _sum(when(col("transaction_channel") == "atm", 1).otherwise(0))
                .alias("atm_transactions"),
            _sum(when(col("transaction_channel") == "pos", 1).otherwise(0))
                .alias("pos_transactions"),
            # International transactions
            _sum(when(col("is_international"), 1).otherwise(0))
                .alias("international_transactions")
        )
        
        # Calculate customer tenure
        customer_agg = customer_agg.withColumn(
            "customer_tenure_days",
            datediff(col("last_transaction_date"), col("first_transaction_date"))
        )
        
        # Calculate transaction frequency
        customer_agg = customer_agg.withColumn(
            "avg_transactions_per_month",
            (col("total_transactions") / 
             (col("customer_tenure_days") / 30.0))
        )
        
        # Customer segmentation
        customer_agg = customer_agg.withColumn(
            "customer_segment",
            when(col("total_spent") > 100000, "VIP")
            .when(col("total_spent") > 50000, "Premium")
            .when(col("total_spent") > 10000, "Gold")
            .otherwise("Standard")
        )
        
        customer_agg = customer_agg.withColumn(
            "risk_category",
            when(col("avg_fraud_score") > 30, "High Risk")
            .when(col("avg_fraud_score") > 15, "Medium Risk")
            .otherwise("Low Risk")
        )
        
        return customer_agg
    
    def merchant_analytics(self, df):
        """
        Create merchant-level analytics
        
        Args:
            df: Transaction DataFrame
        
        Returns:
            Merchant analytics DataFrame
        """
        logger.info("Computing merchant analytics")
        
        merchant_agg = df.groupBy("merchant_id", "merchant_category").agg(
            count("transaction_id").alias("transaction_count"),
            _sum("transaction_amount").alias("total_revenue"),
            avg("transaction_amount").alias("avg_transaction_amount"),
            count(when(col("fraud_risk_level").isin(["high", "critical"]), 1))
                .alias("suspicious_transactions"),
            (count(when(col("fraud_risk_level").isin(["high", "critical"]), 1)) / 
             count("transaction_id") * 100).alias("fraud_rate_percentage")
        )
        
        # Rank merchants by revenue
        window_spec = Window.orderBy(col("total_revenue").desc())
        merchant_agg = merchant_agg.withColumn(
            "revenue_rank",
            rank().over(window_spec)
        )
        
        # Flag high-risk merchants
        merchant_agg = merchant_agg.withColumn(
            "is_high_risk_merchant",
            when(col("fraud_rate_percentage") > 5, True).otherwise(False)
        )
        
        return merchant_agg
    
    def time_series_aggregation(self, df):
        """
        Create time-series aggregations for trend analysis
        
        Args:
            df: Transaction DataFrame
        
        Returns:
            Time-series DataFrame
        """
        logger.info("Creating time-series aggregations")
        
        # Daily aggregations
        daily_agg = df.groupBy(
            date_format("transaction_date", "yyyy-MM-dd").alias("date")
        ).agg(
            count("transaction_id").alias("daily_transaction_count"),
            _sum("transaction_amount").alias("daily_total_amount"),
            avg("transaction_amount").alias("daily_avg_amount"),
            count(when(col("fraud_risk_level") == "critical", 1))
                .alias("daily_critical_frauds"),
            count(when(col("is_international"), 1))
                .alias("daily_international_count")
        )
        
        # Add day of week
        daily_agg = daily_agg.withColumn(
            "day_of_week",
            date_format("date", "EEEE")
        )
        
        # Calculate moving averages
        window_7day = Window.orderBy("date").rowsBetween(-6, 0)
        daily_agg = daily_agg.withColumn(
            "moving_avg_7day_amount",
            avg("daily_total_amount").over(window_7day)
        )
        
        daily_agg = daily_agg.withColumn(
            "moving_avg_7day_count",
            avg("daily_transaction_count").over(window_7day)
        )
        
        return daily_agg
    
    def save_results(self, df, output_path, format="parquet", mode="overwrite"):
        """
        Save processed data to output
        
        Args:
            df: DataFrame to save
            output_path: Output location
            format: Output format (parquet, csv, json)
            mode: Write mode (overwrite, append)
        """
        logger.info(f"Saving results to {output_path}")
        
        if format == "csv":
            df.write.mode(mode) \
                .option("header", "true") \
                .csv(output_path)
        elif format == "json":
            df.write.mode(mode).json(output_path)
        else:  # parquet
            df.write.mode(mode).parquet(output_path)
        
        logger.info(f"Successfully saved {df.count()} records")
    
    def run_pipeline(self, input_path, output_base_path, file_format="parquet"):
        """
        Run the complete processing pipeline
        
        Args:
            input_path: Input data location
            output_base_path: Base path for outputs
            file_format: Input file format
        """
        logger.info("=" * 80)
        logger.info("Starting Banking Transaction Processing Pipeline")
        logger.info("=" * 80)
        
        try:
            # Load data
            df = self.load_transactions(input_path, file_format)
            
            # Data quality checks
            df = self.data_quality_checks(df)
            
            # Feature engineering
            df = self.feature_engineering(df)
            
            # Fraud detection
            df = self.detect_fraud(df)
            
            # Cache the processed dataframe as it will be used multiple times
            df.cache()
            
            # Save processed transactions
            self.save_results(
                df,
                f"{output_base_path}/processed_transactions",
                format="parquet"
            )
            
            # Generate customer analytics
            customer_analytics = self.customer_aggregations(df)
            self.save_results(
                customer_analytics,
                f"{output_base_path}/customer_analytics",
                format="parquet"
            )
            
            # Generate merchant analytics
            merchant_analytics = self.merchant_analytics(df)
            self.save_results(
                merchant_analytics,
                f"{output_base_path}/merchant_analytics",
                format="parquet"
            )
            
            # Generate time-series data
            time_series = self.time_series_aggregation(df)
            self.save_results(
                time_series,
                f"{output_base_path}/time_series_daily",
                format="parquet"
            )
            
            # Extract high-risk transactions for review
            high_risk = df.filter(col("fraud_risk_level").isin(["high", "critical"]))
            self.save_results(
                high_risk,
                f"{output_base_path}/high_risk_transactions",
                format="parquet"
            )
            
            # Unpersist cached data
            df.unpersist()
            
            logger.info("=" * 80)
            logger.info("Pipeline completed successfully!")
            logger.info("=" * 80)
            
        except Exception as e:
            logger.error(f"Pipeline failed: {str(e)}", exc_info=True)
            raise
        finally:
            self.spark.stop()


def main():
    """Main execution function"""
    # Configuration
    INPUT_PATH = "C:/114002/input/sas/transactions"
    OUTPUT_PATH = "C:/114002/output/sas/banking_analytics"
    FILE_FORMAT = "parquet"  # or 'csv', 'json'
    
    # Initialize processor
    processor = BankingTransactionProcessor()
    
    # Run pipeline
    processor.run_pipeline(INPUT_PATH, OUTPUT_PATH, FILE_FORMAT)


if __name__ == "__main__":
    main()