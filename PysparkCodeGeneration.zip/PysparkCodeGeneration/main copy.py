from fastapi import FastAPI, UploadFile, File, Form
from pydantic import BaseModel
from typing import List, Dict
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
import os,yaml
import tempfile
from typing import Optional
from fastapi import HTTPException
from sas_to_technical_spec_final_api import reverse_engineering 
from sas_technical_spec_to_pyspark_final_api import forward_engineering


app = FastAPI()

# -------------------------
# CORS
# -------------------------
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

configFile = r'C:\Users\2157537\OneDrive - TCS COM PROD\Desktop\CTO Projects\Pyspark_api\configure.yaml'
with open(configFile, 'r') as configFile:
    config = yaml.load(configFile, Loader=yaml.SafeLoader)  

def outputfolder_path(progam_type):
    if progam_type == 'SAS':
        outputDir = config['OUTPUT_DIRECTORY_SAS']
    elif progam_type == 'COBOL':
        outputDir = config['OUTPUT_DIRECTORY_COBOL']
    elif progam_type == 'EZTRIEVE':
        outputDir = config['OUTPUT_DIRECTORY_EZTRIEVE']
    return outputDir

# -------------------------
# Response Model
# -------------------------


class ValidationMetrics(BaseModel):
    final_cov_score: float
    final_accuracy_score: float

class UsecaseResponse(BaseModel):
    returnCode: int                  # 0 = success, 1 = failure
    returnMessage: str               # "success" | "failure" or a descriptive message
    usecase_id: str
    usecase_name: str
    technology_type: str
    output_folder: Optional[str] = None
    output_files: Optional[List[str]] = None
    validation_score: Optional[Dict[str, ValidationMetrics]] = None
    error: Optional[str] = None


# -------------------------
# Generate Spec API
# -------------------------
@app.post("/GenerateREspec", response_model=UsecaseResponse)
async def GenerateREspec(
    usecase_id: str = Form(...),
    usecase_name: str = Form(...),
    technology_type: str = Form(...),
    input_folder: str = Form(...),  # Only used if your backend needs it
    logical_units_file: UploadFile = File(...)
):
    # 1) Basic validation on file extension (optional: also validate content-type)
    filename_lower = logical_units_file.filename.lower()
    if not filename_lower.endswith((".yml", ".yaml")):
        raise HTTPException(status_code=400, detail="Only YAML files are allowed.")

    # 2) Read file once
    contents = await logical_units_file.read()
    if not contents:
        raise HTTPException(status_code=400, detail="Uploaded file is empty.")

    # 3) Validate UTF-8 + YAML
    try:
        _ = yaml.safe_load(contents.decode("utf-8"))
    except UnicodeDecodeError:
        raise HTTPException(status_code=400, detail="File must be UTF-8 encoded.")
    except yaml.YAMLError as e:
        raise HTTPException(status_code=400, detail=f"Invalid YAML: {e}")

    # 4) Persist to a temporary file and pass PATH to backend
    suffix = ".yaml" if filename_lower.endswith(".yaml") else ".yml"
    tmp_path = None
    try:
        with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
            tmp.write(contents)
            tmp_path = tmp.name

        # Call your backend with consistent parameter names
        result, output_folder, output_files,validation_score = reverse_engineering(
            technology_type,
            tmp_path,
            input_folder,usecase_id,usecase_name
            
        )

        is_success = bool(result)
        return UsecaseResponse(
            returnCode=0 if is_success else 1,
            returnMessage="success" if is_success else "failure",
            usecase_id=usecase_id,
            usecase_name=usecase_name,
            technology_type=technology_type,
            output_folder=output_folder if is_success else None,
            output_files=output_files if is_success else None,
            validation_score=validation_score,
            error=None if is_success else "Processing failed"
        )

    except Exception as e:
        # On unhandled exceptions, return failure but keep schema consistent
        return UsecaseResponse(
            returnCode=1,
            returnMessage="failure",
            usecase_id=usecase_id,
            usecase_name=usecase_name,
            technology_type=technology_type,
            output_folder=None,
            output_files=None,
            validation_score=None,
            error=str(e)
        )

    finally:
        # 5) Cleanup the temp file
        if tmp_path and os.path.exists(tmp_path):
            try:
                os.unlink(tmp_path)
            except OSError:
                pass


@app.post("/GenerateFEspec", response_model=UsecaseResponse)
async def GenerateFEspec(
    usecase_id: str = Form(...),
    usecase_name: str = Form(...),
    technology_type: str = Form(...),
    input_folder: str = Form(...),  # Only used if your backend needs it
    logical_units_file: UploadFile = File(...)
):
    # 1) Basic validation on file extension (optional: also validate content-type)
    filename_lower = logical_units_file.filename.lower()
    if not filename_lower.endswith((".yml", ".yaml")):
        raise HTTPException(status_code=400, detail="Only YAML files are allowed.")

    # 2) Read file once
    contents = await logical_units_file.read()
    if not contents:
        raise HTTPException(status_code=400, detail="Uploaded file is empty.")

    # 3) Validate UTF-8 + YAML
    try:
        _ = yaml.safe_load(contents.decode("utf-8"))
    except UnicodeDecodeError:
        raise HTTPException(status_code=400, detail="File must be UTF-8 encoded.")
    except yaml.YAMLError as e:
        raise HTTPException(status_code=400, detail=f"Invalid YAML: {e}")

    # 4) Persist to a temporary file and pass PATH to backend
    suffix = ".yaml" if filename_lower.endswith(".yaml") else ".yml"
    tmp_path = None
    try:
        with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
            tmp.write(contents)
            tmp_path = tmp.name

        # Call your backend with consistent parameter names
        result, output_folder, output_files,validation_score = forward_engineering(
            technology_type,
            tmp_path,
            input_folder,usecase_id,usecase_name
            
        )

        is_success = bool(result)
        return UsecaseResponse(
            returnCode=0 if is_success else 1,
            returnMessage="success" if is_success else "failure",
            usecase_id=usecase_id,
            usecase_name=usecase_name,
            technology_type=technology_type,
            output_folder=output_folder if is_success else None,
            output_files=output_files if is_success else None,
            validation_score=validation_score,
            error=None if is_success else "Processing failed"
        )

    except Exception as e:
        # On unhandled exceptions, return failure but keep schema consistent
        return UsecaseResponse(
            returnCode=1,
            returnMessage="failure",
            usecase_id=usecase_id,
            usecase_name=usecase_name,
            technology_type=technology_type,
            output_folder=None,
            output_files=None,
            validation_score=None,
            error=str(e)
        )

    finally:
        # 5) Cleanup the temp file
        if tmp_path and os.path.exists(tmp_path):
            try:
                os.unlink(tmp_path)
            except OSError:
                pass

@app.get("/DownloadFileRE/{program_type}/{filename}")
def DownloadFileRE(program_type: str, filename: str):
    # 1. Allow only .yaml or .yml
    if not (filename.lower().endswith(".yaml") or filename.lower().endswith(".yml")):
        raise HTTPException(status_code=400, detail="Only YAML files are allowed for download.")

    # 2. Get the folder path for program type
    folder = outputfolder_path(program_type)

    # 3. Build full file path
    file_path = os.path.join(folder, filename)

    # 4. Check file existence
    if not os.path.isfile(file_path):
        raise HTTPException(status_code=404, detail="File not found")

    # 5. Serve file with correct YAML MIME type
    return FileResponse(
        path=file_path,
        filename=filename,
        media_type="application/x-yaml"
    )

@app.get("/DownloadFileFE/{program_type}/{filename}")
def DownloadFileFE(program_type: str, filename: str):
    # 1. Allow only .yaml or .yml
    if not (filename.lower().endswith(".py")):
        raise HTTPException(status_code=400, detail="Only python(.py) files are allowed for download.")

    # 2. Get the folder path for program type
    folder = outputfolder_path(program_type)

    # 3. Build full file path
    file_path = os.path.join(folder, filename)

    # 4. Check file existence
    if not os.path.isfile(file_path):
        raise HTTPException(status_code=404, detail="File not found")

    # 5. Serve file with correct YAML MIME type
    return FileResponse(
        path=file_path,
        filename=filename,
        media_type="application/x-yaml"
    )

@app.get("/ViewFileRE/{program_type}/{filename}")
def ViewFileRE(program_type: str,filename: str):
    if not (filename.lower().endswith(".yaml") or filename.lower().endswith(".yml")):
        raise HTTPException(status_code=400, detail="Only YAML files are allowed for view.")

    # 2. Get the folder path for program type
    folder = outputfolder_path(program_type)

    file_path = os.path.join(folder, filename)

    if not os.path.isfile(file_path):
        raise HTTPException(status_code=404, detail="File not found")

    try:
        with open(file_path, "r", encoding="utf-8") as f:
            content = f.read()

        return {
            "filename": filename,
            "content": content
        }

    except UnicodeDecodeError:
        raise HTTPException(
            status_code=400,
            detail="File is not a text-readable format"
        )
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=str(e)
        )

@app.get("/ViewFileFE/{program_type}/{filename}")
def ViewFileFE(program_type: str,filename: str):
    if not (filename.lower().endswith(".py")):
        raise HTTPException(status_code=400, detail="Only python(.py) files are allowed for view.")

    # 2. Get the folder path for program type
    folder = outputfolder_path(program_type)

    file_path = os.path.join(folder, filename)

    if not os.path.isfile(file_path):
        raise HTTPException(status_code=404, detail="File not found")

    try:
        with open(file_path, "r", encoding="utf-8") as f:
            content = f.read()

        return {
            "filename": filename,
            "content": content
        }

    except UnicodeDecodeError:
        raise HTTPException(
            status_code=400,
            detail="File is not a text-readable format"
        )
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=str(e)
        )