'use client';
import type { JSX } from 'react/jsx-runtime';

export function FigmatoReactNative(): JSX.Element {

  return (
    <>
       <div className="flex flex-col h-[35rem] mt-2 bg-[#f9f9f9] dark:bg-[#1f1f1f]  rounded-lg border border-gray-700">        
        <iframe
          src="http://localhost:8503" // Your Streamlit app URL
          width="100%"
          height="545px"
          frameBorder="0"
          title="Streamlit Pipeline Generator"
          style={{
            border: '1px solid #ccc',
            borderRadius: '8px'
          }}
        />                               
        </div>
    </>
  );
}

export default FigmatoReactNative;