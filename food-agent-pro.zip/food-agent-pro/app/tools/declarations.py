"""Tool (function) declarations exposed to Gemini for function calling.

These describe WHAT the agent can do. The actual execution is wired in
services/agent.py, which maps each tool name to a function in services/orders.py.
"""

TOOL_DECLARATIONS = [
    {
        "name": "search_menu",
        "description": "Search the restaurant menu. Use to answer questions about dishes, "
                       "find items by keyword, filter veg/non-veg, price, or category.",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "keyword, e.g. 'paneer' or 'spicy'"},
                "veg_only": {"type": "boolean", "description": "true=veg only, false=non-veg only"},
                "max_price": {"type": "number", "description": "maximum price in rupees"},
                "category": {"type": "string",
                             "description": "one of Starters, Mains, Breads, Rice, Desserts, Drinks"},
            },
        },
    },
    {
        "name": "add_to_cart",
        "description": "Add a menu item to the customer's cart. Use the exact menu item id.",
        "parameters": {
            "type": "object",
            "properties": {
                "item_id": {"type": "string", "description": "menu item id, e.g. 'rice-2'"},
                "qty": {"type": "integer", "description": "quantity, default 1"},
            },
            "required": ["item_id"],
        },
    },
    {
        "name": "remove_from_cart",
        "description": "Remove a menu item from the cart entirely.",
        "parameters": {
            "type": "object",
            "properties": {"item_id": {"type": "string"}},
            "required": ["item_id"],
        },
    },
    {
        "name": "view_cart",
        "description": "Show the current cart contents and total.",
        "parameters": {"type": "object", "properties": {}},
    },
    {
        "name": "place_order",
        "description": "Place the order for everything currently in the cart. "
                       "Only call after the customer confirms they want to order.",
        "parameters": {
            "type": "object",
            "properties": {
                "customer_name": {"type": "string"},
                "note": {"type": "string", "description": "special instructions"},
            },
        },
    },
    {
        "name": "get_order_status",
        "description": "Look up the status of an existing order by its order id (e.g. 'SRK-1042').",
        "parameters": {
            "type": "object",
            "properties": {"order_id": {"type": "string"}},
            "required": ["order_id"],
        },
    },
]
