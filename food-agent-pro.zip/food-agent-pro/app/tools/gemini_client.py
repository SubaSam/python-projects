"""Thin Gemini REST client with retry, backoff, and clear error messages."""
import time
import random
import requests

from ..config import GEMINI_API_KEY, GEMINI_MODEL, GEMINI_BASE, GEMINI_TIMEOUT, GEMINI_MAX_RETRIES


class GeminiError(Exception):
    def __init__(self, message, kind="unknown"):
        super().__init__(message)
        self.kind = kind          # "auth" | "model" | "rate_limit" | "network" | "unknown"


def _url():
    return f"{GEMINI_BASE}/{GEMINI_MODEL}:generateContent"


def generate(payload: dict) -> dict:
    """Call Gemini generateContent with retry on 429/5xx. Returns raw JSON."""
    if not GEMINI_API_KEY:
        raise GeminiError("No GEMINI_API_KEY configured. Add it to your .env file.", "auth")

    last_err = None
    for attempt in range(GEMINI_MAX_RETRIES):
        try:
            resp = requests.post(_url(), params={"key": GEMINI_API_KEY},
                                 json=payload, timeout=GEMINI_TIMEOUT)
        except requests.RequestException as e:
            last_err = GeminiError(f"Network error reaching Gemini: {e}", "network")
            time.sleep(_backoff(attempt))
            continue

        if resp.status_code == 200:
            return resp.json()
        if resp.status_code in (401, 403):
            raise GeminiError("Gemini rejected the API key (401/403). Check GEMINI_API_KEY.", "auth")
        if resp.status_code == 404:
            raise GeminiError(
                f"Model '{GEMINI_MODEL}' not found (404). Set a valid GEMINI_MODEL "
                f"(e.g. gemini-2.5-flash).", "model")
        if resp.status_code == 429:
            last_err = GeminiError("Rate limited by Gemini (429). Slow down or check quota.", "rate_limit")
            time.sleep(_backoff(attempt))
            continue
        if 500 <= resp.status_code < 600:
            last_err = GeminiError(f"Gemini server error ({resp.status_code}).", "network")
            time.sleep(_backoff(attempt))
            continue
        raise GeminiError(f"Unexpected Gemini response {resp.status_code}: {resp.text[:200]}", "unknown")

    raise last_err or GeminiError("Gemini call failed after retries.", "unknown")


def _backoff(attempt: int) -> float:
    # exponential backoff with jitter: ~0.5s, 1s, 2s ...
    return (0.5 * (2 ** attempt)) + random.uniform(0, 0.3)
