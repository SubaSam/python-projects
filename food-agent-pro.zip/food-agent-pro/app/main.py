"""FastAPI web layer. Thin: it validates input, opens a DB session, and delegates
to the service/agent layers. All business logic lives in app/services.
"""
import uuid
from pathlib import Path
from contextlib import contextmanager

from fastapi import FastAPI, Depends
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from .config import RESTAURANT_NAME
from .db.models import SessionLocal, init_db
from .db.seed import seed
from .services import orders as svc
from .services.agent import run_agent

app = FastAPI(title="Food Agent Pro")
STATIC_DIR = Path(__file__).parent / "static"


@app.on_event("startup")
def _startup():
    init_db()
    try:
        seed()   # idempotent
    except Exception as e:   # noqa: BLE001
        # DB may be unreachable; surface clearly in logs but don't crash import
        print(f"[startup] seed skipped: {e}")


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# ------------------------------- schemas ----------------------------------
class ChatMsg(BaseModel):
    role: str
    text: str


class ChatIn(BaseModel):
    message: str
    session_id: str | None = None
    history: list[ChatMsg] = []


class OrderStatusIn(BaseModel):
    order_id: str
    status: str


# ------------------------------- routes -----------------------------------
@app.get("/api/menu")
def api_menu(db=Depends(get_db)):
    return {"restaurant": RESTAURANT_NAME, "items": svc.list_menu(db)}


@app.post("/api/chat")
def api_chat(body: ChatIn, db=Depends(get_db)):
    session_id = body.session_id or ("web-" + uuid.uuid4().hex[:12])
    history = [{"role": m.role, "text": m.text} for m in body.history]
    result = run_agent(db, session_id, body.message, history)
    result["session_id"] = session_id
    return result


@app.get("/api/cart/{session_id}")
def api_cart(session_id: str, db=Depends(get_db)):
    return svc.cart_view(db, session_id)


@app.get("/api/order/{public_id}")
def api_get_order(public_id: str, db=Depends(get_db)):
    o = svc.get_order(db, public_id)
    return o or {"error": "not found"}


@app.post("/api/order/status")
def api_order_status(body: OrderStatusIn, db=Depends(get_db)):
    """Advance an order through the state machine (used by an ops dashboard)."""
    return svc.advance_order(db, body.order_id, body.status)


# ------------------------------- static -----------------------------------
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


@app.get("/")
def index():
    return FileResponse(STATIC_DIR / "index.html")
