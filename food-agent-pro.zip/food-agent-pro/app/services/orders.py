"""Business logic for menu, cart, and orders. Kept separate from the web layer."""
import random
from sqlalchemy import select

from ..db.models import (
    SessionLocal, MenuItem, Order, OrderItem, ChatSession, can_transition
)


# ------------------------------- menu -------------------------------------
def list_menu(db):
    rows = db.execute(select(MenuItem)).scalars().all()
    return [m.to_dict() for m in rows]


def search_menu(db, query="", veg_only=None, max_price=None, category=None):
    """Filter the menu. All args optional; used by the agent's search tool."""
    stmt = select(MenuItem)
    rows = db.execute(stmt).scalars().all()
    q = (query or "").lower()
    out = []
    for m in rows:
        if q and q not in m.name.lower() and q not in (m.description or "").lower() \
                and not any(q in t for t in (m.tags or [])):
            continue
        if veg_only is True and not m.veg:
            continue
        if veg_only is False and m.veg:
            continue
        if max_price is not None and float(m.price) > float(max_price):
            continue
        if category and category.lower() != m.category.lower():
            continue
        if not m.in_stock:
            continue
        out.append(m.to_dict())
    return out


def get_item(db, item_id):
    m = db.get(MenuItem, item_id)
    return m.to_dict() if m else None


# ------------------------------- session/cart ------------------------------
def get_or_create_session(db, session_id):
    s = db.execute(select(ChatSession).where(ChatSession.session_id == session_id)).scalar_one_or_none()
    if not s:
        s = ChatSession(session_id=session_id, history=[], cart={})
        db.add(s)
        db.commit()
        db.refresh(s)
    return s


def cart_view(db, session_id):
    s = get_or_create_session(db, session_id)
    lines, total = [], 0.0
    for iid, qty in (s.cart or {}).items():
        m = db.get(MenuItem, iid)
        if not m:
            continue
        sub = float(m.price) * qty
        total += sub
        lines.append({"id": iid, "name": m.name, "price": float(m.price),
                      "qty": qty, "subtotal": sub})
    return {"lines": lines, "total": total}


def cart_add(db, session_id, item_id, qty=1):
    s = get_or_create_session(db, session_id)
    m = db.get(MenuItem, item_id)
    if not m:
        return {"ok": False, "error": f"No menu item '{item_id}'."}
    if not m.in_stock:
        return {"ok": False, "error": f"{m.name} is out of stock."}
    cart = dict(s.cart or {})
    cart[item_id] = cart.get(item_id, 0) + int(qty)
    if cart[item_id] < 1:
        cart.pop(item_id, None)
    s.cart = cart
    db.commit()
    return {"ok": True, "cart": cart_view(db, session_id), "added": m.name}


def cart_remove(db, session_id, item_id):
    s = get_or_create_session(db, session_id)
    cart = dict(s.cart or {})
    removed = cart.pop(item_id, None)
    s.cart = cart
    db.commit()
    return {"ok": True, "cart": cart_view(db, session_id), "removed": removed is not None}


# ------------------------------- orders -----------------------------------
def place_order(db, session_id, customer_name="Guest", note=""):
    s = get_or_create_session(db, session_id)
    if not s.cart:
        return {"ok": False, "error": "Cart is empty."}
    order = Order(
        public_id="SRK-" + str(random.randint(1000, 9999)),
        customer_name=customer_name or "Guest",
        session_id=session_id, status="placed", note=note or "", total=0,
    )
    total = 0.0
    for iid, qty in s.cart.items():
        m = db.get(MenuItem, iid)
        if not m:
            continue
        total += float(m.price) * qty
        order.items.append(OrderItem(menu_item_id=iid, name=m.name, price=m.price, qty=qty))
    if not order.items:
        return {"ok": False, "error": "No valid items in cart."}
    order.total = total
    db.add(order)
    s.cart = {}                 # clear cart after ordering
    db.commit()
    db.refresh(order)
    return {"ok": True, "order": order.to_dict()}


def get_order(db, public_id):
    o = db.execute(select(Order).where(Order.public_id == public_id)).scalar_one_or_none()
    return o.to_dict() if o else None


def advance_order(db, public_id, new_status):
    """Move an order to a new status, enforcing the state machine."""
    o = db.execute(select(Order).where(Order.public_id == public_id)).scalar_one_or_none()
    if not o:
        return {"ok": False, "error": "Order not found."}
    if not can_transition(o.status, new_status):
        return {"ok": False,
                "error": f"Cannot move order from '{o.status}' to '{new_status}'."}
    o.status = new_status
    db.commit()
    return {"ok": True, "order": o.to_dict()}
