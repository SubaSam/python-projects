"""The agent: builds the prompt, runs Gemini's function-calling loop, executes
tools against the service layer, and returns the final reply + cart state.
"""
from ..config import RESTAURANT_NAME
from ..tools.declarations import TOOL_DECLARATIONS
from ..tools.gemini_client import generate, GeminiError
from . import orders as svc

MAX_TOOL_ROUNDS = 5   # safety cap on tool-call loop


def _system_prompt():
    return (
        f"You are the ordering assistant for {RESTAURANT_NAME}, an Indian restaurant. "
        "Help customers explore the menu and place orders. "
        "Use the provided tools to search the menu, manage the cart, and place orders — "
        "do not guess prices or invent dishes; always rely on tool results. "
        "Only place an order after the customer clearly confirms. "
        "Be warm, concise, and helpful. Prices are in Indian Rupees. "
        "Politely decline anything unrelated to this restaurant."
    )


def _execute_tool(db, session_id, name, args):
    """Map a tool name to the corresponding service function."""
    if name == "search_menu":
        return {"results": svc.search_menu(
            db, query=args.get("query", ""), veg_only=args.get("veg_only"),
            max_price=args.get("max_price"), category=args.get("category"))}
    if name == "add_to_cart":
        return svc.cart_add(db, session_id, args.get("item_id", ""), args.get("qty", 1))
    if name == "remove_from_cart":
        return svc.cart_remove(db, session_id, args.get("item_id", ""))
    if name == "view_cart":
        return svc.cart_view(db, session_id)
    if name == "place_order":
        return svc.place_order(db, session_id,
                               customer_name=args.get("customer_name", "Guest"),
                               note=args.get("note", ""))
    if name == "get_order_status":
        o = svc.get_order(db, args.get("order_id", ""))
        return o or {"error": "Order not found."}
    return {"error": f"Unknown tool {name}"}


def _contents_from_history(history):
    contents = []
    for h in history:
        role = "user" if h.get("role") == "user" else "model"
        contents.append({"role": role, "parts": [{"text": h.get("text", "")}]})
    return contents


def run_agent(db, session_id, user_message, history):
    """Returns dict: {reply, cart, error?}"""
    contents = _contents_from_history(history)
    contents.append({"role": "user", "parts": [{"text": user_message}]})

    tools = [{"function_declarations": TOOL_DECLARATIONS}]
    payload = {
        "system_instruction": {"parts": [{"text": _system_prompt()}]},
        "contents": contents,
        "tools": tools,
        "generationConfig": {"temperature": 0.5},
    }

    try:
        for _ in range(MAX_TOOL_ROUNDS):
            data = generate(payload)
            candidate = data["candidates"][0]
            parts = candidate["content"].get("parts", [])

            # collect any function calls in this turn
            calls = [p["functionCall"] for p in parts if "functionCall" in p]
            if not calls:
                # no tool calls -> this is the final text answer
                text = "".join(p.get("text", "") for p in parts).strip()
                return {"reply": text or "How can I help with your order?",
                        "cart": svc.cart_view(db, session_id)}

            # append the model's function-call turn, then our results
            contents.append({"role": "model", "parts": parts})
            tool_response_parts = []
            for call in calls:
                name = call.get("name", "")
                args = call.get("args", {}) or {}
                result = _execute_tool(db, session_id, name, args)
                tool_response_parts.append({
                    "functionResponse": {"name": name, "response": {"result": result}}
                })
            contents.append({"role": "user", "parts": tool_response_parts})
            payload["contents"] = contents

        # ran out of rounds
        return {"reply": "Sorry, that request got too complex. Could you rephrase?",
                "cart": svc.cart_view(db, session_id)}

    except GeminiError as e:
        return {"reply": _friendly_error(e), "cart": svc.cart_view(db, session_id),
                "error": e.kind}


def _friendly_error(e: GeminiError) -> str:
    msgs = {
        "auth": "The assistant isn't configured correctly (API key issue). "
                "Please check GEMINI_API_KEY in .env.",
        "model": "The configured AI model wasn't found. Set GEMINI_MODEL to a valid "
                 "model like gemini-2.5-flash in .env.",
        "rate_limit": "We're getting a lot of requests right now. Please wait a few "
                      "seconds and try again.",
        "network": "I'm having trouble reaching the assistant. Please try again in a moment.",
    }
    return msgs.get(e.kind, f"Something went wrong: {e}")
