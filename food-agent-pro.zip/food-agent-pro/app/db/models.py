"""SQLAlchemy ORM models and database engine setup (PostgreSQL)."""
from datetime import datetime
from sqlalchemy import (
    create_engine, Column, Integer, String, Boolean, Numeric, DateTime, ForeignKey, Text, JSON
)
from sqlalchemy.orm import declarative_base, relationship, sessionmaker

from ..config import DATABASE_URL

engine = create_engine(DATABASE_URL, pool_pre_ping=True, future=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)
Base = declarative_base()


# ------------------------- order state machine ----------------------------
# Valid order statuses and the transitions allowed between them.
ORDER_STATES = ["placed", "confirmed", "preparing", "out_for_delivery", "delivered", "cancelled"]
ALLOWED_TRANSITIONS = {
    "placed": ["confirmed", "cancelled"],
    "confirmed": ["preparing", "cancelled"],
    "preparing": ["out_for_delivery", "cancelled"],
    "out_for_delivery": ["delivered"],
    "delivered": [],
    "cancelled": [],
}


def can_transition(current: str, new: str) -> bool:
    return new in ALLOWED_TRANSITIONS.get(current, [])


# ------------------------------- models ------------------------------------
class MenuItem(Base):
    __tablename__ = "menu_items"
    id = Column(String(64), primary_key=True)          # e.g. "main-1"
    name = Column(String(200), nullable=False)
    category = Column(String(100), nullable=False, index=True)
    price = Column(Numeric(10, 2), nullable=False)
    veg = Column(Boolean, default=True)
    description = Column(Text, default="")
    tags = Column(JSON, default=list)
    in_stock = Column(Boolean, default=True)

    def to_dict(self):
        return {
            "id": self.id, "name": self.name, "category": self.category,
            "price": float(self.price), "veg": self.veg,
            "description": self.description, "tags": self.tags or [],
            "in_stock": self.in_stock,
        }


class Order(Base):
    __tablename__ = "orders"
    id = Column(Integer, primary_key=True, autoincrement=True)
    public_id = Column(String(32), unique=True, index=True)   # e.g. "SRK-1042"
    customer_name = Column(String(200), default="Guest")
    session_id = Column(String(64), index=True)
    status = Column(String(32), default="placed", index=True)
    total = Column(Numeric(10, 2), default=0)
    note = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    items = relationship("OrderItem", back_populates="order", cascade="all, delete-orphan")

    def to_dict(self):
        return {
            "order_id": self.public_id, "customer_name": self.customer_name,
            "status": self.status, "total": float(self.total), "note": self.note,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "items": [i.to_dict() for i in self.items],
        }


class OrderItem(Base):
    __tablename__ = "order_items"
    id = Column(Integer, primary_key=True, autoincrement=True)
    order_id = Column(Integer, ForeignKey("orders.id"))
    menu_item_id = Column(String(64), ForeignKey("menu_items.id"))
    name = Column(String(200))
    price = Column(Numeric(10, 2))
    qty = Column(Integer, default=1)

    order = relationship("Order", back_populates="items")

    def to_dict(self):
        return {"id": self.menu_item_id, "name": self.name,
                "price": float(self.price), "qty": self.qty,
                "subtotal": float(self.price) * self.qty}


class ChatSession(Base):
    __tablename__ = "chat_sessions"
    id = Column(Integer, primary_key=True, autoincrement=True)
    session_id = Column(String(64), unique=True, index=True)
    history = Column(JSON, default=list)     # [{role, text}, ...]
    cart = Column(JSON, default=dict)        # {menu_item_id: qty}
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


def init_db():
    Base.metadata.create_all(bind=engine)
    