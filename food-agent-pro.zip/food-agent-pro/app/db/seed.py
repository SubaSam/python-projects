"""Seed the menu table with initial data. Safe to run repeatedly (upsert)."""
from .models import SessionLocal, MenuItem, init_db

SEED_MENU = [
    ("starter-1", "Paneer Tikka", "Starters", 220, True,
     "Char-grilled cottage cheese cubes marinated in yogurt and spices.", ["popular", "spicy"]),
    ("starter-2", "Chicken 65", "Starters", 260, False,
     "Crispy fried chicken tossed with curry leaves and red chillies.", ["spicy"]),
    ("starter-3", "Veg Spring Rolls", "Starters", 180, True,
     "Golden rolls stuffed with seasoned vegetables. Served with sweet chilli dip.", []),
    ("main-1", "Butter Chicken", "Mains", 340, False,
     "Tandoori chicken simmered in a creamy tomato and butter gravy.", ["popular"]),
    ("main-2", "Paneer Butter Masala", "Mains", 300, True,
     "Cottage cheese in a rich, mildly sweet tomato-cashew gravy.", ["popular"]),
    ("main-3", "Dal Makhani", "Mains", 260, True,
     "Slow-cooked black lentils with cream and butter.", []),
    ("bread-1", "Butter Naan", "Breads", 50, True, "Soft leavened flatbread brushed with butter.", []),
    ("bread-2", "Garlic Naan", "Breads", 60, True,
     "Naan topped with fresh garlic and coriander.", ["popular"]),
    ("rice-1", "Veg Biryani", "Rice", 280, True,
     "Fragrant basmati rice cooked with mixed vegetables and whole spices.", []),
    ("rice-2", "Chicken Biryani", "Rice", 320, False,
     "Layered basmati rice and marinated chicken, dum-cooked to perfection.", ["popular", "spicy"]),
    ("dessert-1", "Gulab Jamun", "Desserts", 120, True,
     "Warm milk-solid dumplings soaked in cardamom sugar syrup. (2 pcs)", ["popular"]),
    ("dessert-2", "Mango Kulfi", "Desserts", 130, True,
     "Traditional dense frozen dessert with real mango.", []),
    ("drink-1", "Masala Chai", "Drinks", 60, True, "Spiced Indian tea brewed with milk.", []),
    ("drink-2", "Sweet Lassi", "Drinks", 90, True, "Chilled sweetened yogurt drink.", []),
]


def seed():
    init_db()
    db = SessionLocal()
    try:
        for iid, name, cat, price, veg, desc, tags in SEED_MENU:
            existing = db.get(MenuItem, iid)
            if existing:
                existing.name, existing.category, existing.price = name, cat, price
                existing.veg, existing.description, existing.tags = veg, desc, tags
            else:
                db.add(MenuItem(id=iid, name=name, category=cat, price=price,
                                veg=veg, description=desc, tags=tags, in_stock=True))
        db.commit()
        print(f"Seeded {len(SEED_MENU)} menu items.")
    finally:
        db.close()


if __name__ == "__main__":
    seed()
