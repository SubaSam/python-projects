"""Central configuration, loaded from environment (.env)."""
import os
from dotenv import load_dotenv

load_dotenv()

# --- Gemini ---
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-3.1-flash-lite")
GEMINI_BASE = "https://generativelanguage.googleapis.com/v1beta/models"
GEMINI_TIMEOUT = int(os.getenv("GEMINI_TIMEOUT", "30"))
GEMINI_MAX_RETRIES = int(os.getenv("GEMINI_MAX_RETRIES", "3"))

# --- Database (PostgreSQL) ---
# Example: postgresql://postgres:password@localhost:5432/food_agent
DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://postgres:postgres@localhost:5432/food_agent")

RESTAURANT_NAME = os.getenv("RESTAURANT_NAME", "Spice Route Kitchen")
