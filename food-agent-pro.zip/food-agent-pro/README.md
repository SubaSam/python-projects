# Spice Route Kitchen — Professional Food Ordering Agent

A production-structured customer ordering **agent** for a restaurant. It chats with
customers, searches the menu, manages a cart, and places orders — powered by **Google
Gemini function calling**, a **FastAPI** backend split into proper layers, and a
**PostgreSQL** database with a real order state machine.

This is the upgraded version of the earlier prototype: the agent now uses real tools
instead of a JSON trick, the cart and orders are persisted, sessions survive restarts,
and the Gemini client retries on rate limits.

---

## Architecture

```
app/
├── config.py            # env-driven settings (Gemini + DB)
├── main.py              # FastAPI web layer (thin — validates, delegates)
├── db/
│   ├── models.py        # SQLAlchemy models + ORDER STATE MACHINE
│   └── seed.py          # seed the menu table (idempotent)
├── services/
│   ├── orders.py        # business logic: menu, cart, orders
│   └── agent.py         # the AGENT: Gemini function-calling loop
├── tools/
│   ├── declarations.py  # tool/function definitions given to Gemini
│   └── gemini_client.py # Gemini REST client with retry + error typing
└── static/
    └── index.html       # styled UI (menu + server-driven cart + chat)
```

**Layered on purpose:** the web layer never contains business logic; services never
know about HTTP; the agent orchestrates tools but delegates execution to services.
This is how real backends are organized.

### The agent (function calling)
Instead of asking the model to "reply in JSON", the agent gives Gemini a set of **tools**
(`search_menu`, `add_to_cart`, `remove_from_cart`, `view_cart`, `place_order`,
`get_order_status`). Gemini decides which to call; the backend executes them against the
service layer and feeds results back until the model produces a final reply. The cart is
**server-owned** — the UI shows whatever the server returns, so the agent and the buttons
can never disagree.

### Order state machine
Orders move through: `placed → confirmed → preparing → out_for_delivery → delivered`
(or `cancelled`). Invalid jumps (e.g. `placed → delivered`) are rejected in
`db/models.py::can_transition`.

---

## Setup

### 1. Install PostgreSQL and create the database
Install PostgreSQL, then create a database:
```sql
CREATE DATABASE food_agent;
```
(Default connection assumes user `postgres` / password `postgres` on `localhost:5432` —
change it in `.env` to match your setup.)

### 2. Python dependencies
```
pip install -r requirements.txt
```

### 3. Configure
```
cp .env.example .env
```
Edit `.env`:
- paste your Gemini key into `GEMINI_API_KEY` (get one at https://aistudio.google.com/apikey)
- set `DATABASE_URL` to your Postgres connection string

### 4. Run
```
uvicorn app.main:app --reload
```
On first start it creates the tables and seeds the menu automatically.
Open http://127.0.0.1:8000

---

## API

| Endpoint | Method | Purpose |
|---|---|---|
| `/api/menu` | GET | Full menu |
| `/api/chat` | POST | Talk to the agent; returns reply + current cart + session_id |
| `/api/cart/{session_id}` | GET | Current cart for a session |
| `/api/order/{public_id}` | GET | Look up an order |
| `/api/order/status` | POST | Advance an order's status (ops/kitchen use) |

---

## Notes & next steps

- **Data privacy:** the Gemini free tier may use request data for training. Do not send
  real customer PII (names, phones, addresses, payment) through a free key — move to a
  paid tier / Vertex AI before handling real orders.
- **This is the agent + data core.** Production would add: user authentication, a payment
  gateway, live delivery tracking, a restaurant/kitchen dashboard, notifications,
  observability (logging/metrics), and containerized deployment.
- **Customising the menu:** edit `app/db/seed.py` and restart (seeding is idempotent).
