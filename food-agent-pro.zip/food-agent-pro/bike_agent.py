import sys
import asyncio
from claude_agent_sdk import ClaudeSDKClient, ClaudeAgentOptions, AssistantMessage, TextBlock

# Fix for Windows subprocess support in asyncio
if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())


class ClaudeBikeServiceAgent:
    def __init__(self):
        # Configure options and tool access for local execution
        self.options = ClaudeAgentOptions(
            allowed_tools=["Read", "Edit"],
            permission_mode="acceptEdits"
        )
        self.system_prompt = (
            "You are an automated Bike Service Booking Agent.\n"
            "Your task is to guide the user step-by-step through booking a bike service.\n\n"
            "STEPS TO FOLLOW:\n"
            "1. Ask the user for their Bike Name and Model if not provided.\n"
            "2. Ask what specific service they need (e.g., General Service, Oil Change, Brakes, Full Inspection).\n"
            "3. Ask for their preferred Appointment Date and Time.\n"
            "4. Once all details are collected, display a booking summary and confirm the booking with a unique Booking Reference Code (e.g., BK-9821).\n\n"
            "RULE: Be polite, ask ONE question at a time, and do not make up dates without asking."
        )

    async def start_booking_session(self):
        print("🚲 [Claude Bike Service Agent] Interactive Session Initialized.")
        print("----------------------------------------------------------------")

        async with ClaudeSDKClient(options=self.options) as client:
            # 1. Start session by submitting system instructions and initial greeting
            prompt = f"System Instruction: {self.system_prompt}\n\nStart by greeting the customer and asking for their bike name."
            
            while True:
                # Send prompt to Claude CLI via SDK
                await client.query(prompt)

                # Collect streamed response chunks
                response_chunks = []
                async for message in client.receive_response():
                    if isinstance(message, AssistantMessage):
                        for block in message.content:
                            if isinstance(block, TextBlock):
                                response_chunks.append(block.text)
                    elif hasattr(message, "content") and message.content:
                        response_chunks.append(str(message.content))

                agent_reply = "".join(response_chunks) if response_chunks else "How can I help you today?"
                print(f"\n🦅 Agent: {agent_reply}\n")

                # Check if booking completed
                if "BK-" in agent_reply or "Booking Reference" in agent_reply:
                    print("🎉 [System]: Booking completed successfully!")
                    break

                # Non-blocking async input from console
                user_input = await asyncio.to_thread(input, "👤 You: ")
                
                if user_input.strip().lower() in ["exit", "quit"]:
                    print("Ending session...")
                    break

                # Update prompt for next loop iteration
                prompt = user_input


if __name__ == "__main__":
    agent = ClaudeBikeServiceAgent()
    asyncio.run(agent.start_booking_session())